#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PDE Model Tools - Blender 插件入口

用于将 PDE 引擎的模型文件导入 Blender 进行预览和编辑。

支持文件格式:
- .mesh: 模型文件（Prop/Map/CW）
- .skel: 骨骼文件
- .anim: 动画文件

支持 Blender 版本: 4.5 LTS - 5.1.1
"""

import bpy
import sys
import os
from bpy.props import StringProperty, PointerProperty, BoolProperty, EnumProperty
from bpy.types import AddonPreferences, PropertyGroup

# 强制设置标准输出编码为 UTF-8（Windows 系统必需）
if sys.platform == 'win32':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8')
    # 设置环境变量
    os.environ.setdefault('PYTHONIOENCODING', 'utf-8')

from .log import get_module_logger

log = get_module_logger("CORE")

# 主包名
MAIN_PACKAGE = __package__

# 导出主包名常量
__all__ = ("MAIN_PACKAGE",)

# 全局存储地图枚举项（用于下拉列表）
# 这样可以避免 EnumProperty 回调函数中的编码问题
_level_enum_items = [("-1", "(请先扫描地图) / Scan levels first", "")]


def update_level_enum_items(new_items):
    """
    更新全局的地图枚举项
    
    Args:
        new_items: 新的枚举项列表 [(identifier, name, description), ...]
    """
    global _level_enum_items
    _level_enum_items = new_items if new_items else [("-1", "(请先扫描地图) / Scan levels first", "")]


def get_level_enum_items(scene, context):
    """
    获取地图枚举项（用于下拉列表）
    
    直接返回全局存储的枚举项，避免动态生成时的编码问题。
    """
    return _level_enum_items


class PMT_SceneProperties(PropertyGroup):
    """
    场景级别的属性
    
    用于存储用户在 UI 面板中的选择。
    """
    
    # 骨架导入目标物体
    skel_target_object: PointerProperty(
        name="Target object",
        type=bpy.types.Object,
        description=(
            "选择要将骨架添加到的目标物体，留空则创建新物体\n"
            "Select the target object to add the skeleton to, "
            "or leave blank to create a new object."
        ),
    )  # type: ignore
    
    # 地图选择下拉列表
    selected_level: EnumProperty(
        name="选择地图",
        description="选择要导入的地图",
        items=get_level_enum_items,
    )  # type: ignore
    
    # 地图导入选项
    import_main_mesh: BoolProperty(
        name="主场景 mesh",
        default=True,
        description="导入地图的主场景 mesh 文件",
    )  # type: ignore
    
    import_gates: BoolProperty(
        name="门/出生点 mesh",
        default=True,
        description="导入地图的门和出生点 mesh 文件",
    )  # type: ignore
    
    import_active_objects: BoolProperty(
        name="动态物体 mesh",
        default=True,
        description="导入地图的动态物体 mesh 文件（如风车、雷达等）",
    )  # type: ignore
    
    apply_transforms: BoolProperty(
        name="自动应用变换",
        default=True,
        description="自动应用从脚本解析的位置、旋转、缩放",
    )  # type: ignore


# 导入子模块
from .ui import (
    PMT_OT_ResourceDir,
    PMT_OT_ClearResourceDir,
    PMT_OT_CleanupUnusedData,
    PMT_OT_SelectLevel,
    PMT_PT_UiPanel,
    PMT_PT_StablePanel,
    PMT_PT_ExperimentalPanel,
    PMT_PT_HelpPanel,
)
from .mesh_any.operator import PMT_OT_AnyMesh
from .skel.operator import PMT_OT_Skel
from .anim.operator import PMT_OT_Anim
from .level.operator import PMT_OT_ScanLevels, PMT_OT_ImportLevel


class PMTAddonPreferences(AddonPreferences):
    """
    插件偏好设置
    
    存储资源根目录等用户配置。
    """
    
    bl_idname = __package__
    
    dir_path: StringProperty(
        name="资源根目录",
        subtype="DIR_PATH",
        default="",
        description="可以根据根目录来自动加载贴图",
    )  # type: ignore


# 注册类列表
_classes = (
    # 偏好设置
    PMTAddonPreferences,
    # 场景属性
    PMT_SceneProperties,
    # 操作符
    PMT_OT_ResourceDir,
    PMT_OT_ClearResourceDir,
    PMT_OT_CleanupUnusedData,
    PMT_OT_SelectLevel,
    # 面板（按显示顺序）
    PMT_PT_UiPanel,           # 主面板 - 资源目录设置
    PMT_PT_StablePanel,       # 稳定功能 - 手动导入
    PMT_PT_ExperimentalPanel, # 实验功能 - 地图导入
    PMT_PT_HelpPanel,         # 帮助面板
    # 导入操作符
    PMT_OT_AnyMesh,
    PMT_OT_Anim,
    PMT_OT_Skel,
    # 地图导入操作符
    PMT_OT_ScanLevels,
    PMT_OT_ImportLevel,
)


def register():
    """注册插件"""
    # Windows 系统上强制设置 UTF-8 编码
    if sys.platform == 'win32':
        # 尝试设置默认编码（Python 3.7+）
        try:
            import locale
            # 设置为 UTF-8
            if hasattr(locale, 'setlocale'):
                locale.setlocale(locale.LC_ALL, '')
        except Exception:
            pass
    
    # 注册类
    for cls in _classes:
        bpy.utils.register_class(cls)
    
    # 注册场景属性
    bpy.types.Scene.pmt_props = PointerProperty(type=PMT_SceneProperties)
    
    log.info("=" * 50)
    log.info("PDE Model Tools v0.2.0 已启用")
    log.info("支持 Blender 4.5 LTS - 5.1.1")
    log.info("=" * 50)


def unregister():
    """注销插件"""
    # 注销场景属性
    del bpy.types.Scene.pmt_props
    
    # 注销类（逆序）
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    
    log.info("PDE Model Tools 已注销")
