"""
网格处理通用工具模块

提供网格创建、材质设置、边界框创建等通用功能，遵循Blender 4.5 Python API最佳实践。
"""

import bpy
import bmesh
import math
import os
import re
from typing import Set, List, Tuple, Optional, Dict, Any
from mathutils import Matrix, Vector
from ..log import get_module_logger

log = get_module_logger("MESH")

# 常量定义
ROTATION_X_ANGLE = math.radians(90)  # X轴旋转角度（90度）
DEFAULT_UV_LAYER_NAME = "UVMap"  # 默认UV图层名称
COLORMAP_NODE_NAME = "Colormap"  # 颜色贴图节点名称
BSDF_NODE_NAME = "Principled BSDF"  # 原理化BSDF节点名称
ALPHA_MODE_CHANNEL_PACKED = "CHANNEL_PACKED"  # Alpha通道打包模式
MAX_VERTEX_WEIGHT_COUNT = 4  # 每个顶点最多包含的权重数量


def get_root_fix_matrix() -> Matrix:
    """获取根节点修正矩阵 (Game Space Z-up -> Blender Space Y-up)"""
    m = Matrix.Identity(4)
    # X -> X
    m[0][0], m[0][1], m[0][2] = 1.0, 0.0, 0.0
    # Y -> -Z
    m[1][0], m[1][1], m[1][2] = 0.0, 0.0, -1.0
    # Z -> Y
    m[2][0], m[2][1], m[2][2] = 0.0, 1.0, 0.0
    return m


def transform_mesh_data(mesh_data: Dict[str, Any]) -> None:
    """
    将网格数据从 Game Space 转换到 Blender Space
    直接修改 mesh_data 中的顶点、法线、切线等数据
    """
    root_fix = get_root_fix_matrix()
    root_fix_3x3 = root_fix.to_3x3()

    # 1. 转换顶点位置
    if "vertex_data" in mesh_data:
        new_verts = []
        for v in mesh_data["vertex_data"]:
            # v 是 (x, y, z) 元组
            vec = Vector(v)
            new_vec = root_fix @ vec
            new_verts.append((new_vec.x, new_vec.y, new_vec.z))
        mesh_data["vertex_data"] = new_verts

    # 2. 转换法线
    if "normals" in mesh_data and mesh_data["normals"]:
        new_normals = []
        for n in mesh_data["normals"]:
            vec = Vector(n)
            new_vec = root_fix_3x3 @ vec
            new_normals.append((new_vec.x, new_vec.y, new_vec.z))
        mesh_data["normals"] = new_normals

    # 3. 转换切线
    if "tangents" in mesh_data and mesh_data["tangents"]:
        new_tangents = []
        for t in mesh_data["tangents"]:
            vec = Vector(t)
            new_vec = root_fix_3x3 @ vec
            new_tangents.append((new_vec.x, new_vec.y, new_vec.z))
        mesh_data["tangents"] = new_tangents

    # 4. 转换副法线
    if "binormals" in mesh_data and mesh_data["binormals"]:
        new_binormals = []
        for b in mesh_data["binormals"]:
            vec = Vector(b)
            new_vec = root_fix_3x3 @ vec
            new_binormals.append((new_vec.x, new_vec.y, new_vec.z))
        mesh_data["binormals"] = new_binormals
    
    log.debug(f"已将网格数据转换到 Blender Space (应用 Root Fix)")


def create_uv_mapping(mesh: bpy.types.Mesh, uvs: List[Tuple[float, float]]) -> None:
    """
    为网格创建UV映射
    
    Args:
        mesh: 目标网格对象
        uvs: UV坐标列表，每个元素为(u, v)坐标元组
    
    Raises:
        ValueError: 当UV坐标数量与顶点数量不匹配时
    """
    if not uvs:
        log.debug("无UV数据可创建")
        return
        
    if len(uvs) != len(mesh.vertices):
        log.warning(f"UV数量({len(uvs)})与顶点数量({len(mesh.vertices)})不匹配")
    
    # 创建新的UV图层
    uv_layer = mesh.uv_layers.new(name=DEFAULT_UV_LAYER_NAME)
    
    # 为每个多边形的每个循环索引设置UV坐标
    for polygon in mesh.polygons:
        for loop_index in polygon.loop_indices:
            vertex_index = mesh.loops[loop_index].vertex_index
            uv_coordinate = uvs[vertex_index] if vertex_index < len(uvs) else (0.0, 0.0)
            uv_layer.data[loop_index].uv = uv_coordinate


def create_custom_normals(mesh: bpy.types.Mesh, normals: List[Tuple[float, float, float]]) -> None:
    """
    为网格创建自定义法线
    
    使用Blender 4.5 API的最佳实践来设置法线数据，确保兼容性和性能。
    
    Args:
        mesh: 目标网格对象
        normals: 法线向量列表，每个元素为(x, y, z)法线向量
    
    Note:
        如果法线数量与顶点数量不匹配，将自动跳过设置
    """
    if not normals or len(normals) != len(mesh.vertices):
        log.warning(f"法线数量({len(normals)})与顶点数量({len(mesh.vertices)})不匹配")
        return
    
    # 使用Blender 4.5推荐的方法设置自定义法线
    try:
        # 首选方法：使用分割法线设置
        mesh.normals_split_custom_set_from_vertices(normals)
    except (AttributeError, RuntimeError) as e:
        # 备选方法：直接设置顶点法线（兼容性处理）
        log.debug(f"使用备选法线设置方法: {e}")
        for vertex_index, normal_vector in enumerate(normals):
            if vertex_index < len(mesh.vertices):
                mesh.vertices[vertex_index].normal = normal_vector
    
    # 标记网格需要更新法线数据
    mesh.update()


def create_tangent_space_data(mesh: bpy.types.Mesh, tangents: List[Tuple[float, float, float]], 
                            binormals: List[Tuple[float, float, float]]) -> None:
    """
    为网格创建切线空间数据（切线和副法线）
    
    在Blender 4.5中，切线空间数据主要用于法线贴图计算。
    本函数验证数据有效性，但Blender通常会自动计算切线数据。
    
    Args:
        mesh: 目标网格对象
        tangents: 切线向量列表
        binormals: 副法线向量列表
    
    Note:
        Blender会自动计算切线空间数据，这里主要进行数据验证
    """
    if not tangents or not binormals:
        log.debug("缺少切线或副法线数据")
        return
        
    if len(tangents) != len(mesh.vertices) or len(binormals) != len(mesh.vertices):
        log.warning("切线或副法线数量与顶点数量不匹配")
        return
    
    # 验证切线空间数据的有效性
    valid_tangent_count = sum(1 for tangent in tangents if any(tangent))
    valid_binormal_count = sum(1 for binormal in binormals if any(binormal))
    
    log.debug(f"有效切线: {valid_tangent_count}/{len(tangents)}, "
              f"有效副法线: {valid_binormal_count}/{len(binormals)}")
    
    # 在Blender 4.5中，切线空间数据通常由UV映射自动生成
    # 这里主要确保UV图层存在，以便Blender可以正确计算切线
    if not mesh.uv_layers:
        log.debug("缺少UV图层，无法自动生成切线空间数据")
        create_uv_mapping(mesh, [(0.0, 0.0)] * len(mesh.vertices))


def create_vertex_groups_for_rigging(mesh_object: bpy.types.Object, 
                                    bone_indices: List[Tuple[int, int, int, int]], 
                                    bone_weights: List[Tuple[float, float, float, float]],
                                    obj_namess: Optional[List[str]] = None) -> None:
    """
    为网格对象创建顶点组，用于存储权重数据
    
    遵循Blender 4.5的顶点组管理最佳实践，确保权重数据正确有效。
    
    Args:
        mesh_object: 目标网格对象
        bone_indices: 骨骼索引列表，每个元素为4个骨骼索引的元组
        bone_weights: 权重列表，每个元素为4个权重的元组
        obj_namess: Mesh文件中的骨骼名称列表（可能包含重复名称）
    
    Note:
        每个顶点最多包含4个权重，权重总和应为1.0
        
        关于重复名称的处理：
        Mesh文件中的骨骼名称列表可能包含重复名称（如多个索引都叫"knee_l"）。
        这是正常的！这些重复名称应该映射到Skel中的同一个骨骼。
        所以我们直接使用原始名称创建顶点组，不添加任何后缀。
    """
    if not bone_indices or not bone_weights:
        log.debug("缺少索引或权重数据")
        return
        
    if len(bone_indices) != len(mesh_object.data.vertices):
        log.warning(f"索引数量({len(bone_indices)})与顶点数量({len(mesh_object.data.vertices)})不匹配")
        return
    
    # 添加调试信息
    log.debug(f"顶点组创建调试 - 顶点数量: {len(mesh_object.data.vertices)}")
    log.debug(f"索引数据示例: {bone_indices[:3] if bone_indices else '无数据'}")
    log.debug(f"权重数据示例: {bone_weights[:3] if bone_weights else '无数据'}")
    
    # 清理现有顶点组（Blender 4.5推荐做法）
    existing_groups = list(mesh_object.vertex_groups)
    for vertex_group in existing_groups:
        mesh_object.vertex_groups.remove(vertex_group)
    
    # 统计实际使用的索引
    used_indices = set()
    for indices_for_vertex in bone_indices:
        for idx in indices_for_vertex:
            if idx < 255:  # 有效索引
                used_indices.add(idx)
    
    log.debug(f"检测到 {len(used_indices)} 个实际使用的索引: {sorted(used_indices)}")

    # Mesh索引 → 骨骼名称映射
    # 注意：不同的Mesh索引可能映射到同一个名称，这是正常的！
    # 它们应该绑定到Skel中的同一个骨骼
    def get_bone_name(idx: int) -> str:
        if obj_namess and idx < len(obj_namess) and obj_namess[idx]:
            return obj_namess[idx]
        return f"Bone_{idx:03d}"
    
    # 统计名称使用情况（用于日志）
    name_usage = {}  # name -> [indices]
    for idx in used_indices:
        name = get_bone_name(idx)
        if name not in name_usage:
            name_usage[name] = []
        name_usage[name].append(idx)
    
    # 打印重复名称信息
    duplicate_names = {k: v for k, v in name_usage.items() if len(v) > 1}
    if duplicate_names:
        log.debug(f"检测到重复名称映射（正常现象）: {duplicate_names}")
    
    # 收集所有需要创建的唯一顶点组名称
    unique_group_names = set()
    for idx in used_indices:
        unique_group_names.add(get_bone_name(idx))
    
    # 创建顶点组
    created_groups = 0
    for group_name in unique_group_names:
        if group_name not in mesh_object.vertex_groups:
            vertex_group = mesh_object.vertex_groups.new(name=group_name)
            created_groups += 1
            log.debug(f"创建顶点组: {group_name}")
    
    # 为每个顶点分配权重
    # 注意：多个Mesh索引可能对应同一个顶点组名称，权重会累加
    for vertex_index, (indices_for_vertex, weights_for_vertex) in enumerate(zip(bone_indices, bone_weights)):
        for influence_idx in range(MAX_VERTEX_WEIGHT_COUNT):
            if influence_idx < len(indices_for_vertex) and influence_idx < len(weights_for_vertex):
                bone_idx = indices_for_vertex[influence_idx]
                
                if bone_idx < 255:  # 有效索引
                    group_name = get_bone_name(bone_idx)
                    weight_value = weights_for_vertex[influence_idx]
                    
                    # 只添加有效权重（避免极小权重）
                    if weight_value > 0.001:
                        vertex_group = mesh_object.vertex_groups.get(group_name)
                        if vertex_group:
                            vertex_group.add([vertex_index], weight_value, 'REPLACE')
    
    log.info(f"已为网格创建 {created_groups} 个顶点组（共使用 {len(used_indices)} 个骨骼索引）")

def find_best_armature_for_mesh(context: bpy.types.Context, mesh_object: bpy.types.Object) -> Optional[bpy.types.Object]:
    armatures = [obj for obj in context.scene.objects if obj.type == "ARMATURE"]
    if not armatures:
        return None
    if len(armatures) == 1:
        return armatures[0]
    vertex_group_names = {group.name for group in mesh_object.vertex_groups}
    if not vertex_group_names:
        return armatures[0]
    best_armature = None
    best_match = -1
    for armature_obj in armatures:
        bone_names = {bone.name for bone in armature_obj.data.bones}
        match_count = len(vertex_group_names & bone_names)
        if match_count > best_match:
            best_match = match_count
            best_armature = armature_obj
    return best_armature or armatures[0]


def bind_mesh_to_armature(mesh_object: bpy.types.Object, armature_obj: bpy.types.Object) -> bool:
    """
    将网格绑定到骨架（添加 Armature 修改器）
    
    注意：此函数只添加修改器，不改变 mesh 的父物体层级关系
    """
    if not mesh_object or mesh_object.type != "MESH":
        return False
    if not armature_obj or armature_obj.type != "ARMATURE":
        return False
    
    # 添加 Armature 修改器
    armature_mod = None
    for modifier in mesh_object.modifiers:
        if modifier.type == "ARMATURE":
            armature_mod = modifier
            break
    if armature_mod is None:
        armature_mod = mesh_object.modifiers.new(name="Armature", type="ARMATURE")
    armature_mod.object = armature_obj
    armature_mod.use_vertex_groups = True
    armature_mod.use_bone_envelopes = False
    
    # 注意：不改变 mesh 的父物体，保持原有的层级结构
    # mesh 可以作为任意物体的子物体，只需要 Armature 修改器指向骨架即可
    
    return True


def apply_object_transform(object_to_transform: bpy.types.Object) -> None:
    """
    应用标准对象变换设置
    
    设置对象的旋转模式和欧拉角。
    注意：由于我们已经将网格数据转换到了 Blender Space (Y-up)，
    所以这里不需要再旋转对象本身。
    """
    object_to_transform.rotation_mode = "XYZ"
    object_to_transform.rotation_euler = (0.0, 0.0, 0.0)
    log.debug(f"已为对象 {object_to_transform.name} 应用标准变换 (Identity)")


def create_pbr_material(material_name: str, color_map_path: str, mesh_type: str = "Unset",
                       specular_map_path: str = "", diffuse_map_path: str = "") -> bpy.types.Material:
    """
    创建基于物理渲染(PBR)的材质
    
    使用Blender 4.5的节点系统创建完整的PBR材质，支持颜色贴图、镜面反射贴图和漫反射贴图。
    
    Args:
        material_name: 材质名称
        color_map_path: 颜色贴图文件路径
        mesh_type: 网格类型（用于日志记录）
        specular_map_path: 镜面反射贴图文件路径
        diffuse_map_path: 漫反射贴图文件路径
    
    Returns:
        创建的材质对象
    
    Note:
        如果贴图文件不存在，相应的节点将被创建但不加载贴图
    """
    # 创建新材质并启用节点编辑
    material = bpy.data.materials.new(name=material_name)
    material.use_nodes = True
    
    # 获取节点树和链接
    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links
    
    # 清理默认节点
    nodes.clear()
    
    # 创建主着色器节点（遵循Blender 4.5命名规范）
    principled_bsdf_node = nodes.new(type="ShaderNodeBsdfPrincipled")
    principled_bsdf_node.name = BSDF_NODE_NAME
    principled_bsdf_node.location = (0, 0)
    
    # 设置基础材质属性
    principled_bsdf_node.inputs["IOR"].default_value = 1.0  # 折射率设为1.0（空气）
    
    # 创建颜色贴图节点
    color_map_node = nodes.new(type="ShaderNodeTexImage")
    color_map_node.name = COLORMAP_NODE_NAME
    color_map_node.location = (-600, 300)
    
    # 创建镜面反射贴图节点
    specular_map_node = nodes.new(type="ShaderNodeTexImage")
    specular_map_node.name = "SpecularMap"
    specular_map_node.location = (-600, 0)
    
    # 创建漫反射贴图节点
    diffuse_map_node = nodes.new(type="ShaderNodeTexImage")
    diffuse_map_node.name = "DiffuseMap"
    diffuse_map_node.location = (-600, -300)
    
    # 创建输出节点
    material_output_node = nodes.new(type="ShaderNodeOutputMaterial")
    material_output_node.location = (300, 0)
    
    # 加载并连接颜色贴图
    if os.path.exists(color_map_path):
        color_map_node.image = bpy.data.images.load(color_map_path, check_existing=True)
        color_map_node.image.alpha_mode = ALPHA_MODE_CHANNEL_PACKED
        
        # 连接颜色贴图到基础颜色
        links.new(principled_bsdf_node.inputs["Base Color"], color_map_node.outputs["Color"])
        
        # 处理Alpha通道（如果存在）
        # if color_map_node.image and color_map_node.image.depth == 32:
        #     links.new(principled_bsdf_node.inputs["Alpha"], color_map_node.outputs["Alpha"])
        #     material.blend_method = 'BLEND'
        #     # 在Blender 4.5中，shadow_method属性可能已被移除或重命名
        #     # material.shadow_method = 'CLIP'  # 这行代码在Blender 4.5中可能不兼容

        
        # 处理Alpha通道 - 谨慎使用透明度
        if color_map_node.image.depth == 32:
            # 检查是否需要启用透明度
            has_alpha_content = False
            # 默认禁用透明度，除非确实需要
            material.blend_method = 'OPAQUE'
            
            # 只有在明确需要透明度时才启用
            # 从 color_map_node.image 的文件名中提取贴图名称，用于判断是否包含“透明”关键词
            color_map_name = os.path.basename(color_map_path) if os.path.exists(color_map_path) else ""
            if mesh_type == "Prop" and "透明" in color_map_name:
                links.new(principled_bsdf_node.inputs["Alpha"], color_map_node.outputs["Alpha"])
                material.blend_method = 'BLEND'
                has_alpha_content = True
            
            log.debug(f"颜色贴图Alpha处理: 深度={color_map_node.image.depth}, 透明度={has_alpha_content}")

    else:
        log.debug(f"颜色贴图文件不存在: {color_map_path}")
    
    # 加载并连接镜面反射贴图
    if specular_map_path and os.path.exists(specular_map_path):
        specular_map_node.image = bpy.data.images.load(specular_map_path, check_existing=True)
        specular_map_node.image.alpha_mode = 'NONE'
        
        # 连接镜面反射贴图到相应输入（Blender 4.5使用"Specular IOR Level"）
        if "Specular IOR Level" in principled_bsdf_node.inputs:
            links.new(principled_bsdf_node.inputs["Specular IOR Level"], specular_map_node.outputs["Color"])
        elif "Specular" in principled_bsdf_node.inputs:
            links.new(principled_bsdf_node.inputs["Specular"], specular_map_node.outputs["Color"])
    else:
        log.debug("镜面反射贴图文件不存在或未指定")
    
    # 加载并连接漫反射贴图
    if diffuse_map_path and os.path.exists(diffuse_map_path):
        diffuse_map_node.image = bpy.data.images.load(diffuse_map_path, check_existing=True)
        diffuse_map_node.image.alpha_mode = 'NONE'
        
        # 连接漫反射贴图到粗糙度输入
        if "Roughness" in principled_bsdf_node.inputs:
            links.new(principled_bsdf_node.inputs["Roughness"], diffuse_map_node.outputs["Color"])
    else:
        log.debug("漫反射贴图文件不存在或未指定")
    
    # 连接主着色器到输出
    links.new(material_output_node.inputs["Surface"], principled_bsdf_node.outputs["BSDF"])
    
    log.debug(f"已创建PBR材质: {material_name}")
    return material


def setup_material_with_path_processing(
    target_object: bpy.types.Object,
    color_map_name: str,
    color_map_path: str,
    resource_directory_path: str,
    processed_materials_set: Set[str],
    mesh_type: str = "Unset",
    specular_map_path: str = "",
    diffuse_map_path: str = "",
) -> None:
    """
    设置材质并处理路径标准化
    
    遵循Blender 4.5的材质管理最佳实践，处理路径标准化和材质复用。
    
    Args:
        target_object: 目标对象
        color_map_name: 颜色贴图名称
        color_map_path: 颜色贴图相对路径
        resource_directory_path: 资源目录绝对路径
        processed_materials_set: 已处理材质的集合（用于材质复用）
        mesh_type: 网格类型
        specular_map_path: 镜面反射贴图路径
        diffuse_map_path: 漫反射贴图路径
    """
    # 标准化颜色贴图路径
    normalized_color_path = os.path.normpath(color_map_path.lstrip("/").replace("/", os.sep))
    full_color_map_path = os.path.join(resource_directory_path, normalized_color_path)
    
    # 标准化镜面反射贴图路径
    full_specular_map_path = ""
    if specular_map_path:
        normalized_specular_path = os.path.normpath(specular_map_path.lstrip("/").replace("/", os.sep))
        full_specular_map_path = os.path.join(resource_directory_path, normalized_specular_path)
    
    # 标准化漫反射贴图路径
    full_diffuse_map_path = ""
    if diffuse_map_path:
        normalized_diffuse_path = os.path.normpath(diffuse_map_path.lstrip("/").replace("/", os.sep))
        full_diffuse_map_path = os.path.join(resource_directory_path, normalized_diffuse_path)

    # 创建材质唯一标识符
    material_identifier = f"{color_map_name}_{mesh_type}"
    
    # 获取或创建材质（Blender 4.5推荐做法）
    if material_identifier in processed_materials_set and color_map_name in bpy.data.materials:
        # 复用现有材质
        material = bpy.data.materials[color_map_name]
    else:
        # 创建新材质
        material = create_pbr_material(
            color_map_name,
            full_color_map_path,
            mesh_type,
            full_specular_map_path,
            full_diffuse_map_path
        )
        processed_materials_set.add(material_identifier)

    # 分配材质到对象
    if target_object.data.materials:
        target_object.data.materials[0] = material
    else:
        target_object.data.materials.append(material)
    
    log.debug(f"已为对象 {target_object.name} 设置材质: {color_map_name}")


def build_mesh_geometry(mesh_object: bpy.types.Mesh, mesh_data: Dict[str, Any]) -> None:
    """
    构建完整的网格几何体
    
    使用Blender 4.5的API构建网格的顶点、面、UV、法线等几何数据。
    
    Args:
        mesh_object: 目标网格对象
        mesh_data: 包含网格数据的字典
    
    Note:
        确保mesh_data包含必要的顶点数据和面数据
    """
    # 从Python数据构建基础网格几何
    mesh_object.from_pydata(
        mesh_data["vertex_data"],  # 顶点数据
        [],  # 边数据（空列表，Blender会自动生成）
        mesh_data["faces_data"]    # 面数据
    )
    
    # 创建UV映射
    create_uv_mapping(mesh_object, mesh_data["uvs"])
    
    # 创建自定义法线（如果存在）
    if "normals" in mesh_data and mesh_data["normals"]:
        create_custom_normals(mesh_object, mesh_data["normals"])
    
    # 创建切线空间数据（如果存在）
    if "tangents" in mesh_data and "binormals" in mesh_data:
        create_tangent_space_data(mesh_object, mesh_data["tangents"], mesh_data["binormals"])
    
    # 更新网格以应用所有更改
    mesh_object.update()
    
    log.debug(f"已构建网格几何体: {len(mesh_data['vertex_data'])} 个顶点, {len(mesh_data['faces_data'])} 个面")








def create_mesh_object_from_data(
    context: bpy.types.Context,
    mesh_data: Dict[str, Any],
    base_object_name: str,
    object_index: int,
    processed_materials_set: Set[str],
    resource_directory_path: str,
    mesh_type: str = "Unset",
    obj_namess: Optional[List[str]] = None,
) -> Optional[bpy.types.Object]:
    """
    从网格数据创建完整的网格对象
    
    遵循Blender 4.5的对象创建最佳实践，创建包含几何、材质和骨骼系统的完整网格对象。
    实现完善的错误处理机制，确保在数据不完整或API调用失败时能够优雅处理。
    
    Args:
        context: Blender上下文
        mesh_data: 包含网格数据的字典
        base_object_name: 基础对象名称
        object_index: 对象索引
        processed_materials_set: 已处理材质的集合
        resource_directory_path: 资源目录路径
        mesh_type: 网格类型
    
    Returns:
        创建的网格对象，如果创建失败则返回None
    
    Raises:
        ValueError: 当传入的网格数据不完整或无效时
        RuntimeError: 当Blender API调用失败时
    """
    try:
        # 验证输入数据完整性
        if not mesh_data or not isinstance(mesh_data, dict):
            raise ValueError("网格数据为空或格式不正确")
        
        # 转换网格数据坐标系 (Game -> Blender)
        # 这确保了顶点数据与骨骼数据（应用了 Root Fix）处于同一空间
        transform_mesh_data(mesh_data)

        required_keys = ["vertex_data", "faces_data", "uvs", "colormap"]
        for key in required_keys:
            if key not in mesh_data:
                raise ValueError(f"网格数据缺少必要字段: {key}")
        
        # 验证顶点和面数据的有效性
        if not mesh_data["vertex_data"] or not mesh_data["faces_data"]:
            raise ValueError("顶点数据或面数据为空")
        
        # 创建对象名称
        object_name = f"{base_object_name}_{object_index}"
        
        # 创建网格数据和对象（Blender 4.5最佳实践）
        mesh_data_object = bpy.data.meshes.new(object_name)
        if not mesh_data_object:
            raise RuntimeError("创建网格数据对象失败")
            
        mesh_object = bpy.data.objects.new(object_name, mesh_data_object)
        if not mesh_object:
            # 清理已创建的网格数据对象
            bpy.data.meshes.remove(mesh_data_object)
            raise RuntimeError("创建网格对象失败")

        # 链接对象到场景并构建几何
        try:
            context.collection.objects.link(mesh_object)
            build_mesh_geometry(mesh_data_object, mesh_data)
            apply_object_transform(mesh_object)
        except Exception as e:
            # 清理已创建的对象
            bpy.data.objects.remove(mesh_object, do_unlink=True)
            bpy.data.meshes.remove(mesh_data_object)
            raise RuntimeError(f"构建网格几何失败: {e}")

        # 处理材质设置
        color_map_info = mesh_data["colormap"]
        
        if isinstance(color_map_info, dict) and "colormap" in color_map_info:
            # CW类型：包含多个贴图的字典结构
            color_map = color_map_info["colormap"]
            specular_map = color_map_info.get("srmap", {"path": ""})
            diffuse_map = color_map_info.get("drmap", {"path": ""})
            
            if color_map and color_map["name"]:
                setup_material_with_path_processing(
                    mesh_object,
                    color_map["name"],
                    color_map["path"],
                    resource_directory_path,
                    processed_materials_set,
                    mesh_type,
                    specular_map_path=specular_map["path"],
                    diffuse_map_path=diffuse_map["path"]
                )
        elif isinstance(color_map_info, dict) and "name" in color_map_info:
            # 常规类型：直接包含name和path的字典
            if color_map_info["name"]:
                setup_material_with_path_processing(
                    mesh_object,
                    color_map_info["name"],
                    color_map_info["path"],
                    resource_directory_path,
                    processed_materials_set,
                    mesh_type,
                )

        # 为CW类型（角色/武器）创建顶点组（不创建骨架）
        if mesh_type == "CW" and "bone_indices" in mesh_data and "bone_weights" in mesh_data:
            # 创建顶点组，使用读取到的物体名称命名
            create_vertex_groups_for_rigging(
                mesh_object,
                mesh_data["bone_indices"],
                mesh_data["bone_weights"],
                obj_namess
            )
            log.debug(f"已为CW类型网格创建顶点组，不生成骨骼骨架")
            armature_obj = find_best_armature_for_mesh(context, mesh_object)
            if armature_obj and bind_mesh_to_armature(mesh_object, armature_obj):
                log.debug(f"已将网格对象 {object_name} 绑定到骨架: {armature_obj.name}")

        log.info(f"成功创建网格对象: {object_name} (类型: {mesh_type})")
        return mesh_object
        
    except Exception as e:
        log.error(f"创建网格对象失败: {e}")
        return None


def create_bounding_box_object(
    context: bpy.types.Context,
    min_position: Tuple[float, float, float],
    max_position: Tuple[float, float, float],
    base_object_name: str
) -> Optional[bpy.types.Object]:
    """
    创建边界框线框对象
    
    遵循Blender 4.5的几何创建最佳实践，创建用于可视化边界的线框立方体。
    
    Args:
        context: Blender上下文
        min_position: 最小边界坐标 (x, y, z)
        max_position: 最大边界坐标 (x, y, z)
        base_object_name: 基础对象名称
    
    Returns:
        创建的边界框对象，如果创建失败则返回None
    """
    try:
        bbox_name = f"BBox_{base_object_name}"
        
        # 清理之前的边界框对象（Blender 4.5推荐做法）
        if bbox_name in bpy.data.objects:
            existing_bbox = bpy.data.objects[bbox_name]
            bpy.data.objects.remove(existing_bbox, do_unlink=True)
        
        # 创建新的网格数据和对象
        bbox_mesh = bpy.data.meshes.new(bbox_name)
        bbox_object = bpy.data.objects.new(bbox_name, bbox_mesh)
        
        # 链接到场景
        context.collection.objects.link(bbox_object)
        
        # 使用bmesh创建边界框几何（Blender 4.5推荐做法）
        bm = bmesh.new()
        
        # 定义立方体的8个顶点
        cube_vertices = [
            (min_position[0], min_position[1], min_position[2]),  # 0: 最小xyz
            (max_position[0], min_position[1], min_position[2]),  # 1: 最大x, 最小yz
            (max_position[0], max_position[1], min_position[2]),  # 2: 最大xy, 最小z
            (min_position[0], max_position[1], min_position[2]),  # 3: 最小x, 最大y, 最小z
            (min_position[0], min_position[1], max_position[2]),  # 4: 最小xy, 最大z
            (max_position[0], min_position[1], max_position[2]),  # 5: 最大x, 最小y, 最大z
            (max_position[0], max_position[1], max_position[2]),  # 6: 最大xyz
            (min_position[0], max_position[1], max_position[2]),  # 7: 最小x, 最大yz
        ]
        
        # 添加顶点到bmesh
        for vertex_position in cube_vertices:
            bm.verts.new(vertex_position)
        
        # 确保顶点索引有效
        bm.verts.ensure_lookup_table()
        
        # 定义立方体的12条边
        cube_edges = [
            # 底面边 (z = min_z)
            (0, 1), (1, 2), (2, 3), (3, 0),
            # 顶面边 (z = max_z)
            (4, 5), (5, 6), (6, 7), (7, 4),
            # 垂直边
            (0, 4), (1, 5), (2, 6), (3, 7)
        ]
        
        # 添加边到bmesh
        for edge_vertices in cube_edges:
            vertex1 = bm.verts[edge_vertices[0]]
            vertex2 = bm.verts[edge_vertices[1]]
            bm.edges.new([vertex1, vertex2])
        
        # 更新网格
        bm.to_mesh(bbox_mesh)
        bm.free()
        
        # 设置显示模式为线框
        bbox_object.display_type = 'WIRE'
        
        # 创建发光材质（边界框专用）
        bbox_material = bpy.data.materials.new(name=f"{bbox_name}_Material")
        bbox_material.use_nodes = True
        
        # 清理默认节点
        bbox_material.node_tree.nodes.clear()
        
        # 创建节点
        output_node = bbox_material.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
        output_node.location = (300, 0)
        
        emission_node = bbox_material.node_tree.nodes.new(type='ShaderNodeEmission')
        emission_node.location = (0, 0)
        emission_node.inputs['Color'].default_value = (1.0, 0.2, 0.2, 1.0)  # 红色
        emission_node.inputs['Strength'].default_value = 1.5
        
        # 连接节点
        bbox_material.node_tree.links.new(
            emission_node.outputs['Emission'], 
            output_node.inputs['Surface']
        )
        
        # 应用材质
        bbox_object.data.materials.append(bbox_material)
        
        # 应用标准变换
        apply_object_transform(bbox_object)
        
        log.debug(f"已创建边界框: {bbox_name}, 范围: {min_position} 到 {max_position}")
        
        return bbox_object
        
    except Exception as e:
        log.error(f"创建边界框对象失败: {e}")
        return None
