# ui.py
import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from .log import get_module_logger

log = get_module_logger("UI")


class PMT_OT_ResourceDir(Operator):
    """选择资源根目录 \n Select Resource root directory"""

    bl_idname = "pmt.resource_dir"
    bl_label = "Resource Root Dir"

    # 资源根目录
    directory: StringProperty(subtype="DIR_PATH")  # type: ignore

    # 执行操作
    def execute(self, context):
        try:
            # 获取当前插件的偏好设置
            prefs = context.preferences.addons[__package__].preferences
            # 将用户选择的目录保存到偏好设置中
            prefs.dir_path = self.directory
            # 立即保存用户设置
            bpy.ops.wm.save_userpref()

            # 报告成功保存路径
            self.report({"INFO"}, f"路径保存完成: {self.directory}")
            return {"FINISHED"}
        except Exception as e:
            # 报告保存失败
            self.report({"ERROR"}, f"路径保存失败: {str(e)}")
            return {"CANCELLED"}

    def invoke(self, context, event):
        # 调用Blender的文件选择对话框
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PMT_OT_ClearResourceDir(bpy.types.Operator):
    """清空选择的资目录 \n Clear selected resource directory"""

    bl_idname = "pmt.clear_resource_dir"
    bl_label = ""

    def execute(self, context):
        # 获取插件的偏好设置
        prefs = context.preferences.addons[__package__].preferences
        # 清空路径
        prefs.dir_path = ""
        # 立即保存设置
        bpy.ops.wm.save_userpref()

        # 报告成功清除
        self.report({"INFO"}, "游戏资源目录已清除")
        return {"FINISHED"}


class PMT_OT_CleanupUnusedData(bpy.types.Operator):
    """删除所有未使用的数据，包括网格、材质、贴图、骨架等"""

    bl_idname = "pmt.cleanup_unused_data"
    bl_label = "清理未使用数据"

    def execute(self, context):
        try:
            # 清理前统计
            initial_objects = len(bpy.data.objects)
            initial_meshes = len(bpy.data.meshes)
            initial_materials = len(bpy.data.materials)
            initial_textures = len(bpy.data.textures)
            initial_images = len(bpy.data.images)
            initial_armatures = len(bpy.data.armatures)
            initial_actions = len(bpy.data.actions)

            # 执行清理操作
            bpy.ops.outliner.orphans_purge(
                do_local_ids=True, do_linked_ids=True)

            # 再次清理确保彻底
            for _ in range(3):  # 清理3次确保彻底
                bpy.ops.outliner.orphans_purge()

            # 清理后统计
            final_objects = len(bpy.data.objects)
            final_meshes = len(bpy.data.meshes)
            final_materials = len(bpy.data.materials)
            final_textures = len(bpy.data.textures)
            final_images = len(bpy.data.images)
            final_armatures = len(bpy.data.armatures)
            final_actions = len(bpy.data.actions)

            # 计算清理的数量
            deleted_objects = initial_objects - final_objects
            deleted_meshes = initial_meshes - final_meshes
            deleted_materials = initial_materials - final_materials
            deleted_textures = initial_textures - final_textures
            deleted_images = initial_images - final_images
            deleted_armatures = initial_armatures - final_armatures
            deleted_actions = initial_actions - final_actions

            # 构建报告信息
            report_msg = "Cleanup Unused Data:\n"
            report_msg += f"  Object: {deleted_objects}\n"
            report_msg += f"  Mesh: {deleted_meshes}\n"
            report_msg += f"  Material: {deleted_materials}\n"
            report_msg += f"  Texture: {deleted_textures}\n"
            report_msg += f"  Image: {deleted_images}\n"
            report_msg += f"  Armature: {deleted_armatures}\n"
            report_msg += f"  Action: {deleted_actions}"

            # log.info("report_msg")
            self.report({"INFO"}, report_msg)

            return {"FINISHED"}

        except Exception as e:
            error_msg = f"清理失败: {str(e)}"
            log.error(error_msg)
            self.report({"ERROR"}, error_msg)
            return {"CANCELLED"}


class PMT_PT_UiPanel(bpy.types.Panel):
    """导入面板"""

    bl_idname = "PMT_PT_ui_panel"  # Panel 必须加上 _PT_ ~淦！
    bl_label = "PDE模型工具 V0.1.7"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "PMT"

    def draw(self, context):
        """绘制面板"""
        layout = self.layout
        
        # 获取场景属性
        scene = context.scene

        # 🔧 按钮配置
        button_configs = [
            ("模型 - (K8BYTE)", "", "FILE_3D"),
            ("", "pmt.any_mesh", "任意模型 / Any Meshs"),
            ("骨架 - (K8BYTE)", "", "GROUP_BONE"),
        ]
        # 按钮绘制
        for label, operator, text in button_configs:
            if label:  # 分类标签
                layout.label(text=label, icon=text)
            else:  # 操作按钮
                layout.operator(operator, text=text)
        
        # 骨架导入选项：目标物体选择
        box = layout.box()
        row = box.row()
        row.prop(scene.pmt_props, "skel_target_object", text="目标物体")
        row = box.row()
        skel_op = row.operator("pmt.skel", text="导入骨架", icon='GROUP_BONE')
        
        # 继续按钮配置
        button_configs2 = [
            ("动画 - (R8BYTE)", "", "POSE_HLT"),
            ("", "pmt.anim", "动画 (探索中)"),
        ]
        for label, operator, text in button_configs2:
            if label:  # 分类标签
                layout.label(text=label, icon=text)
            else:  # 操作按钮
                layout.operator(operator, text=text)

        # 📂 资源根目录
        layout.label()
        layout.label(text="资源根目录 - (M8BYTE)", icon="FILE_FOLDER")
        box = layout.box()
        row = box.row()
        # 文本居中
        row.alignment = "CENTER"

        # 获取插件的偏好设置
        prefs = context.preferences.addons[__package__].preferences
        if prefs.dir_path:
            # 显示路径
            row.label(text=prefs.dir_path)
            # 操作按钮
            row = box.row()
            row.operator("pmt.clear_resource_dir", text="清除", icon="TRASH")
        else:
            # 显示提示
            row.label(text="设置资源根目录后,可以自动加载贴图!")
            row = box.row()
            # 操作按钮
            row.operator("pmt.resource_dir", text="选择根目录", icon="FILE_FOLDER")

        # 🧹 数据清理
        # layout.label()
        layout.label(text="数据清理 - (工具)", icon="TRASH")
        layout.operator("pmt.cleanup_unused_data",
                        text="删除未使用数据", icon="ORPHAN_DATA")

        # ⚠ 帮助
        layout.label()
        layout.label(text="帮助", icon="HELP")
        notebox = layout.box()
        noterow = notebox.column()
        # 显示帮助
        noterow.label(text="S 8 = 未删除前8字节的原始文件")
        noterow.label(text="NS8 = 删除了前8字节的文件")
        noterow.label(text="除了模型以外,其他文件都还在探索中!")
        noterow.label(text="本项目仅为学习研究，请勿用于商业用途!")
