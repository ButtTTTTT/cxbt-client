# skel\utils.py
import math
import struct

from mathutils import Vector

from ..log import log


def read_header_info(file):
    """读取文件头部信息，包括魔数和骨骼数量"""
    try:
        # 读取魔数
        magic = struct.unpack("<I", file.read(4))[0]
        log.debug("魔数: 0x%x", magic)
        
        # 读取骨骼数量
        bone_count = struct.unpack("<I", file.read(4))[0]
        log.debug("骨骼数量: %s", bone_count)
        
        # 跳过8字节的未知数据 (FFFFFFFF 00000000)
        file.seek(8, 1)
        
        return magic, bone_count
    except struct.error as e:
        log.debug("读取文件头部信息失败: %s", e)
        return None, None


def read_bone_info(file):
    """读取骨骼名称和层级"""
    try:
        # 父级骨骼层级
        level = struct.unpack("<I", file.read(4))[0]
        # log.debug("骨骼层级: %s", level)
        
        # 骨骼名称长度
        name_length = struct.unpack("<I", file.read(4))[0]
        # log.debug("骨骼名称长度: %s", name_length)
        
        # 骨骼名称
        name = file.read(name_length).decode("ascii")

        log.debug("骨骼信息: %s %s", name, level)

        # 返回骨骼名称和层级
        return name, level
    except struct.error as e:
        log.debug("读取骨骼信息失败: %s", e)
        return None


def read_bone_transform(file):
    """读取骨骼变换数据 (位置 + 四元数旋转)"""
    try:
        # 读取位置 (x, y, z)
        position = struct.unpack("<fff", file.read(12))
        # 读取四元数旋转 (qx, qy, qz, qw)
        rotation = struct.unpack("<ffff", file.read(16))
        
        log.debug("位置: %s 旋转: %s", position, rotation)

        return position, rotation
    except struct.error as e:
        log.debug("读取骨骼变换数据失败: %s", e)
        return None


def validate_file(file):
    """验证文件是否是skel文件"""
    try:
        # 保存当前位置
        pos = file.tell()
        # 读取魔数
        magic = struct.unpack("<I", file.read(4))[0]
        # 恢复位置
        file.seek(pos)
        # 检查魔数是否为0x600
        return magic == 0x600
    except Exception as e:
        log.debug("文件验证失败: %s", e)
        return False


def convert_coordinates(coords):
    """转换坐标系"""
    x, y, z = coords

    return x, z, y


def calculate_bone_roll(bone):
    """计算骨骼的roll角度"""
    if "arm" in bone.name.lower():
        return math.radians(90)
    elif "leg" in bone.name.lower():
        return math.radians(-90)
    elif "hand" in bone.name.lower():
        return math.radians(180)
    return 0


def create_bone_chain(edit_bones, bones, transforms):
    """创建骨骼链"""
    bone_dict = {}

    # 创建所有骨骼
    for i, (name, level) in enumerate(bones):
        if i < len(transforms):
            bone = edit_bones.new(name)
            position, rotation = transforms[i]

            # 转换坐标
            pos = convert_coordinates(position)

            # 设置骨骼位置 (简化处理，实际应该使用四元数旋转来计算骨骼方向)
            bone.head = Vector(pos)
            # 简单地沿Z轴延长骨骼
            bone.tail = Vector((pos[0], pos[1], pos[2] + 0.1))

            # 存储骨骼信息
            bone_dict[name] = {"bone": bone, "level": level}

    # 设置父子关系
    for name, data in bone_dict.items():
        bone = data["bone"]
        level = data["level"]

        if level > 1:
            # 查找最近的父骨骼
            parent_level = level - 1
            potential_parents = [
                (n, d) for n, d in bone_dict.items() if d["level"] == parent_level
            ]

            if potential_parents:
                # 选择最近的父骨骼
                closest_parent = min(
                    potential_parents,
                    key=lambda x: (x[1]["bone"].head - bone.head).length,
                )
                bone.parent = closest_parent[1]["bone"]
                # 设置父骨骼的尾为子骨骼的头
                closest_parent[1]["bone"].tail = bone.head


def add_bone_constraints(armature_obj):
    """添加骨骼约束"""
    pose = armature_obj.pose

    # 添加IK约束
    for bone_name in pose.bones:
        if "IK" in bone_name:
            target_name = bone_name.replace("IK", "")
            if target_name in pose.bones:
                constraint = pose.bones[target_name].constraints.new("IK")
                constraint.target = armature_obj
                constraint.subtarget = bone_name