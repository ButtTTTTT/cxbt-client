# __init__.py
import bpy
from bpy.props import StringProperty
from bpy.types import AddonPreferences
from .log import log

# 主包名
MAIN_PACKAGE = __package__

# 导出主包名常量，使子模块可获取到主包名
__all__ = ("MAIN_PACKAGE",)


# 导入子模块
from .ui import PMT_OT_ResourceDir, PMT_OT_ClearResourceDir, PMT_PT_UiPanel
from .mesh_any.base_operator import PMT_OT_AnyMesh
from .skel.operator import PMT_OT_Skel
from .anim.operator import PMT_OT_Anim


# 插件的偏好设置
class PMTAddonPreferences(AddonPreferences):
    bl_idname = __package__

    dir_path: StringProperty(
        name="资源根目录",
        subtype="DIR_PATH",
        default="",
        description="可以根据根目录来自动加载贴图",
    )  # type: ignore


# 类列表
classes = (
    PMTAddonPreferences,
    PMT_OT_ResourceDir,
    PMT_OT_ClearResourceDir,
    PMT_PT_UiPanel,
    PMT_OT_AnyMesh,
    PMT_OT_Anim,
    PMT_OT_Skel,
)


def register():
    # 注册类
    for cls in classes:
        bpy.utils.register_class(cls)
    log.info("插件已启用")

def unregister():
    # 注销类
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    log.info("插件已注销")
