# mesh_cw\operator.py
import math
import os
import traceback
import bmesh
from typing import Set
from mathutils import Vector, Matrix

import bpy
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, CollectionProperty

from . import utils
from ..log import log
from .. import MAIN_PACKAGE

# 常量定义
ROTATION_X = math.radians(90)
DEFAULT_UV_LAYER = "UVMap"
COLORMAP_NODE_NAME = "Colormap"
BSDF_NODE_NAME = "Principled BSDF"


class PMT_OT_MeshCharacterWeapon(bpy.types.Operator, ImportHelper):
    """Import a .mesh file"""

    bl_idname = "pmt.mesh_character_weapon"
    bl_label = "导入武器和人物.mesh"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".mesh"
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})  # type: ignore
    files: CollectionProperty(type=bpy.types.OperatorFileListElement)  # type: ignore
    _processed_materials: Set[str] = set()

    def execute(self, context):
        folder = os.path.dirname(self.filepath)
        success_count = 0
        error_count = 0

        for file_elem in self.files:
            filepath = os.path.join(folder, file_elem.name)

            try:
                # 检查文件路径
                if not os.path.exists(filepath):
                    self.report({"WARNING"}, f"文件不存在: {filepath}")
                    error_count += 1
                    continue

                # 读取二进制文件
                with open(filepath, "rb") as file:
                    data = file.read()

                # 获取基础名称
                mesh_name = os.path.splitext(os.path.basename(filepath))[0]

                log.debug("<<< 读取到的模型名称: %s", mesh_name)

                # 分割网格数据
                mesh_obj, minmax_data = utils.split_mesh(self, data)
                
                # 创建MinPos MaxPos虚线方块
                self._create_minmax_box(context, minmax_data)

                # 获取游戏资源路径
                dir_path = context.preferences.addons[MAIN_PACKAGE].preferences.dir_path

                # 循环索引
                idx = 0
                # 读取数据块
                for mesh_item in mesh_obj:
                    # 物体名称
                    obj_name = mesh_item["name"]
                    # 读取顶点数据
                    vertices = mesh_item["vertices"]["data"]
                    # 读取面数据
                    faces = mesh_item["faces"]["data"]
                    # 获取法线​​数据
                    normals = mesh_item["normals"]
                    uvs = mesh_item["uvs"]  # 读取UV坐标
                    colormap = mesh_item["colormap"]  # 读取ColorMap
                    log.debug("colormap x :%s", colormap.name)

                    # 创建新网格
                    new_mesh = bpy.data.meshes.new(f"{mesh_name}_{idx}")
                    new_obj = bpy.data.objects.new(f"{mesh_name}_{idx}", new_mesh)

                    # 将对象添加到场景中
                    context.collection.objects.link(new_obj)

                    # 创建顶点 点, 线, 面
                    new_mesh.from_pydata(vertices, [], faces)

                    # 创建UV图层
                    uv_layer = new_mesh.uv_layers.new(name="UVMap")

                    # 为每个循环（loop）设置UV坐标
                    for face in new_mesh.polygons:
                        for loop_idx in face.loop_indices:
                            # 获取顶点索引
                            vertex_idx = new_mesh.loops[loop_idx].vertex_index
                            # 设置UV坐标
                            uv_layer.data[loop_idx].uv = uvs[vertex_idx]

                    # 启用平滑着色
                    new_mesh.shade_smooth()

                    # 准备法线​​数据
                    loop_normals = []
                    for poly in new_mesh.polygons:
                        for vertex_idx in poly.vertices:
                            loop_normals.append(normals[vertex_idx])

                    # 设置自定义法线​​
                    new_mesh.normals_split_custom_set(loop_normals)

                    # 设置材质
                    if colormap.name:
                        self._setup_material(
                            new_obj, colormap.name, colormap.path, dir_path
                        )

                    # 更新网格
                    new_mesh.update()

                    # 设置物体的位置
                    new_obj.location = (0, 0, 0)
                    # 首先，设置旋转模式为欧拉角
                    new_obj.rotation_mode = "XYZ"
                    # 设置X轴的旋转值为90度（转换为弧度）
                    new_obj.rotation_euler = (math.radians(90), 0, 0)

                    # 循环索引+1
                    idx += 1

                success_count += 1
            except Exception as e:
                self.report({"ERROR"}, f"模型加载失败: {file_elem.name} - {e}")
                traceback.print_exc()
                error_count += 1

        self.report({"INFO"}, f"导入完成，成功: {success_count}，失败: {error_count}")
        return {"FINISHED"}

    def _setup_material(
        self,
        obj: bpy.types.Object,
        colormap_name: str,
        colormap_path: str,
        dir_path: str,
    ) -> None:
        """设置材质"""
        # 转换Unix路径为Windows路径
        unix_path = colormap_path.lstrip("/")  # 去掉开头的斜杠
        windows_relative_path = unix_path.replace("/", "\\")  # 替换斜杠方向
        dds_full_path = os.path.join(dir_path, windows_relative_path)  # 拼接完整路径

        # 检查文件是否存在
        if not os.path.exists(dds_full_path) and dir_path:
            log.error(f"纹理文件不存在: {dds_full_path}")

        # 检查材质是否已存在
        if colormap_name in self._processed_materials:
            mat = bpy.data.materials[colormap_name]
        else:
            mat = self._create_material(colormap_name, dds_full_path)
            self._processed_materials.add(colormap_name)

        # 分配材质
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)

    def _create_material(
        self, colormap_name: str, texture_path: str
    ) -> bpy.types.Material:
        """创建材质"""
        mat = bpy.data.materials.new(name=colormap_name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        # 清理默认节点
        nodes.clear()

        # 创建节点
        bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
        bsdf.name = BSDF_NODE_NAME
        bsdf.location = (0, 0)

        bsdf.inputs["IOR"].default_value = 1.0  # 设置折射率为1.0

        tex_node = nodes.new(type="ShaderNodeTexImage")
        tex_node.name = COLORMAP_NODE_NAME
        tex_node.location = (-300, 0)
        tex_node.image = bpy.data.images.get(colormap_name)

        # 加载纹理文件
        if os.path.exists(texture_path):
            tex_node.image = bpy.data.images.load(texture_path, check_existing=True)
            # 设置Alpha模式为通道打包
            tex_node.image.alpha_mode = "CHANNEL_PACKED"
            log.debug(f"成功加载纹理: {colormap_name}")
        else:
            # 文件不存在，记录错误
            log.error(f"纹理文件不存在: {colormap_name}")

        output = nodes.new(type="ShaderNodeOutputMaterial")
        output.location = (300, 0)

        # 连接节点
        links.new(bsdf.inputs["Base Color"], tex_node.outputs["Color"])
        links.new(output.inputs["Surface"], bsdf.outputs["BSDF"])

        return mat

    def _get_texture(self, name: str) -> bpy.types.Image:
        """获取或加载贴图"""
        return bpy.data.images.get(name)

    def _create_minmax_box(self, context, minmax_data):
        """创建 Min/Max 包围盒，并以 3D 游标为枢轴旋转 90°（X 轴）"""
        # 1. 记录当前游标位置（后面还要把物体平移过去）
        cursor_world = context.scene.cursor.location.copy()

        for mm_data in minmax_data:
            min_pos = Vector(mm_data.min_pos)
            max_pos = Vector(mm_data.max_pos)
            obj_name = mm_data.name

            # 2. 包围盒中心、尺寸
            center = (min_pos + max_pos) / 2
            dimensions = max_pos - min_pos

            # 3. 创建单位立方体
            mesh = bpy.data.meshes.new(obj_name + "_mesh")
            cube = bpy.data.objects.new(obj_name, mesh)
            context.collection.objects.link(cube)

            bm = bmesh.new()
            bmesh.ops.create_cube(bm, size=1.0)

            # 4. 先把顶点缩放到包围盒尺寸
            bmesh.ops.scale(bm,
                            vec=dimensions,
                            verts=bm.verts)

            # 5. 把 3D 游标设到世界原点（旋转枢轴）
            context.scene.cursor.location = (0, 0, 0)

            # 6. 以游标为枢轴，绕游标 X 轴旋转 90°
            bpy.context.view_layer.objects.active = cube
            cube.select_set(True)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.transform.rotate(value=math.radians(90),
                                    orient_axis='X',
                                    orient_type='CURSOR')   # 关键：以游标为枢轴
            cube.select_set(False)

            # 7. 把物体移到最终包围盒中心
            cube.location = center

            # 8. 显示设置
            cube.display_type = 'WIRE'
            cube.show_name = True
            cube.rotation_mode = 'XYZ'

        # 9. 恢复游标
        context.scene.cursor.location = cursor_world

            