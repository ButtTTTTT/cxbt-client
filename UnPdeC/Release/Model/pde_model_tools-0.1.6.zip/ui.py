# ui.py
import bpy
from bpy.props import StringProperty
from bpy.types import Operator

from .log import log


class PMT_OT_ResourceDir(Operator):
    """选择资源根目录 \n Select Resource root directory"""

    bl_idname = "pmt.resource_dir"
    bl_label = "Resource Root Dir"

    # 资源根目录
    directory: StringProperty(subtype="DIR_PATH")  # type: ignore

    # 执行操作
    def execute(self, context):
        try:
            # 获取当前插件的偏好设置
            prefs = context.preferences.addons[__package__].preferences
            # 将用户选择的目录保存到偏好设置中
            prefs.dir_path = self.directory
            # 立即保存用户设置
            bpy.ops.wm.save_userpref()

            # 报告成功保存路径
            self.report({"INFO"}, f"路径保存完成: {self.directory}")
            return {"FINISHED"}
        except Exception as e:
            # 报告保存失败
            self.report({"ERROR"}, f"路径保存失败: {str(e)}")
            return {"CANCELLED"}

    def invoke(self, context, event):
        # 调用Blender的文件选择对话框
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class PMT_OT_ClearResourceDir(bpy.types.Operator):
    """清空选择的资目录 \n Clear selected resource directory"""

    bl_idname = "pmt.clear_resource_dir"
    bl_label = ""

    def execute(self, context):
        # 获取插件的偏好设置
        prefs = context.preferences.addons[__package__].preferences
        # 清空路径
        prefs.dir_path = ""
        # 立即保存设置
        bpy.ops.wm.save_userpref()

        # 报告成功清除
        self.report({"INFO"}, "游戏资源目录已清除")
        return {"FINISHED"}


class PMT_PT_UiPanel(bpy.types.Panel):
    """导入面板"""

    bl_idname = "PMT_PT_ui_panel"  # Panel 必须加上 _PT_ ~淦！
    bl_label = "PDE模型工具"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "PMT"

    def draw(self, context):
        """绘制面板"""
        layout = self.layout

        # 按钮配置
        button_configs = [
            ("模型", "", "FILE_3D"),
            ("", "pmt.any_mesh", "任意模型 / Any Meshs"),
            ("", "pmt.mesh_map", "地图 (即将移除)"),
            ("", "pmt.mesh_prop", "道具( 即将移除)"),
            ("", "pmt.mesh_character_weapon", "人物&武器 (即将移除)"),
            ("骨架", "", "GROUP_BONE"),
            ("", "pmt.skel", "骨架 (探索中)"),
            ("动画", "", "POSE_HLT"),
            ("", "pmt.anim", "动画 (探索中)"),
        ]

        # 按钮绘制
        for label, operator, text in button_configs:
            if label:  # 分类标签
                layout.label(text=label, icon=text)
            else:  # 操作按钮
                layout.operator(operator, text=text)

        # 资源根目录
        layout.label(text="资源根目录", icon="FILE_FOLDER")
        box = layout.box()
        row = box.row()
        # 文本居中
        row.alignment = "CENTER"

        # 获取插件的偏好设置
        prefs = context.preferences.addons[__package__].preferences
        if prefs.dir_path:
            # 显示路径
            row.label(text=prefs.dir_path)
            # 操作按钮
            row = box.row()
            row.operator("pmt.clear_resource_dir", text="清除", icon="TRASH")
        else:
            # 显示提示
            row.label(text="选择资源根目录后,可以自动加载贴图")
            row = box.row()
            # 操作按钮
            row.operator("pmt.resource_dir", text="选择根目录", icon="FILE_FOLDER")
