import bpy
import os
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, CollectionProperty
from typing import Set

from .. import MAIN_PACKAGE
from ..log import log
from .mesh_parser import MeshParser
from .common import create_mesh_object, create_bounding_box


def import_mesh(self, context: bpy.types.Context, filepath: str) -> Set[str]:
    """导入网格的通用方法"""
    try:
        # 获取资源路径
        res_dir_path = context.preferences.addons[MAIN_PACKAGE].preferences.dir_path

        # 解析网格文件
        parser = MeshParser()
        mesh_objects = parser.parse_file(filepath)

        if not mesh_objects:
            log.debug(f"未能读取到有效的网格数据,Mesh文件可能损坏!")
            return {"CANCELLED"}

        base_name = os.path.splitext(os.path.basename(filepath))[0]
        processed_materials = set()
        imported_count = 0

        # 根据网格类型进行特定处理
        mesh_type = parser.MESH_GVAL["type"]
        log.info(f"处理 {mesh_type} 类型的网格文件: {base_name}")

        # 处理每个网格对象
        for idx, mesh_data in enumerate(mesh_objects, 1):
            obj = create_mesh_object(
                context,
                mesh_data,
                base_name,
                idx,
                processed_materials,
                res_dir_path,
                mesh_type,
            )
            if obj:
                # # 根据网格类型设置特定属性
                # if mesh_type == "Prop":
                #     # 道具类型特定处理
                #     obj.scale = (1.0, 1.0, 1.0)  # 道具通常不需要缩放
                # elif mesh_type == "Map":
                #     # 地图类型特定处理
                #     obj.scale = (0.01, 0.01, 0.01)  # 地图通常需要缩小
                # elif mesh_type == "Character":
                #     # 角色/武器类型特定处理
                #     obj.scale = (1.0, 1.0, 1.0)  # 角色通常不需要缩放

                # 设置自定义属性记录网格类型
                # obj["mesh_type"] = mesh_type
                imported_count += 1

        # 清理旧的边界框
        objects_to_remove = []
        for obj in bpy.data.objects:
            if obj.name.startswith(f"BBox_{base_name}"):
                objects_to_remove.append(obj)
        for obj in objects_to_remove:
            bpy.data.objects.remove(obj, do_unlink=True)
        
        # 创建边界框
        bbox_count = 0
        if hasattr(parser, 'bbox_list') and parser.bbox_list:
            # CW类型：为每个物体创建边界框
            for i, bbox_data in enumerate(parser.bbox_list):
                bbox_name = f"{base_name}_{bbox_data['name']}"
                bbox_obj = create_bounding_box(
                    context,
                    bbox_data['min_pos'],
                    bbox_data['max_pos'],
                    bbox_name
                )
                if bbox_obj:
                    bbox_count += 1
                    # log.info(f"已创建边界框 {i+1}: {bbox_data['name']} - Min{bbox_data['min_pos']}, Max{bbox_data['max_pos']}")
        elif parser.min_pos is not None and parser.max_pos is not None:
            # Map/Prop类型：创建单个边界框
            bbox_obj = create_bounding_box(
                context,
                parser.min_pos,
                parser.max_pos,
                base_name
            )
            if bbox_obj:
                bbox_count = 1
                # log.info(f"已创建边界框: Min{parser.min_pos}, Max{parser.max_pos}")

        report_msg = f"导入完成: 共 {parser.MESH_INCLUDE_OBJECT} 个物体, 成功导入{imported_count} 个物体，类型: {mesh_type}, 版本: {parser.MESH_GVAL['version']}"
        if bbox_count > 0:
            report_msg += f", 已创建 {bbox_count} 个边界框"
        log.info(report_msg)
        self.report({"INFO"}, report_msg)
        return {"FINISHED"}
    except Exception as e:
        log.error(f"导入失败: {e}", exc_info=True)
        self.report({"ERROR"}, f"严重错误: {str(e)}")
        return {"CANCELLED"}


class PMT_OT_AnyMesh(bpy.types.Operator, ImportHelper):
    """通用网格导入 \n General Mesh Import"""

    bl_idname = "pmt.any_mesh"
    bl_label = "Any Meshs"
    bl_options = {"REGISTER", "UNDO"}

    # 文件选择
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement, options={"HIDDEN"}
    )  # type: ignore
    directory: StringProperty(subtype="DIR_PATH")  # type: ignore
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})  # type: ignore

    def execute(self, context):
        # 成功导入数量
        imported_total = 0
        # 失败导入数量
        import_errors = []

        if not self.files:
            self.report({"ERROR"}, "未选择任何文件")
            return {"CANCELLED"}

        for file_elem in self.files:
            filepath = os.path.join(self.directory, file_elem.name)
            if not os.path.exists(filepath):
                import_errors.append(f"文件不存在: {file_elem.name}")
                continue

            try:
                result = import_mesh(self, context, filepath)
                if result == {"FINISHED"}:
                    imported_total += 1
            except Exception as e:
                log.error(f"导入失败 {file_elem.name}: {e}", exc_info=True)
                import_errors.append(f"{file_elem.name}: {str(e)}")

        if import_errors:
            self.report({"WARNING"}, f"导入失败:\n" + "\n".join(import_errors))
        # else:
            # self.report({"INFO"}, f"导入完成,共 {imported_total} 个Mesh文件")

        return {"FINISHED"}
