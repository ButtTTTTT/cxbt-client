﻿import mmap
import struct
import logging
import os
from typing import List, Tuple, Optional, NamedTuple, TypedDict, Dict, Any

from ..log import log


class MeshParser:
    """网格解析器类，封装网格文件解析逻辑"""

    def reset(self):
        """重置解析器状态"""
        # MinPos MaxPos占用字节大小
        self.MINPOS_MAXPOS_SIZE = 0x18

        # 该Mesh文件包含的物体数量
        self.MESH_INCLUDE_OBJECT = 0

        # 已读取物体数量
        self.MESH_OBJECT_READED = 0

        # MinPos MaxPos数据
        self.min_pos = None
        self.max_pos = None
        # 所有物体的边界框数据列表
        self.bbox_list = []

        # 网格头部配置
        self.MESH_GVAL_CFG = {
            # Unset
            "Unset": {
                "type": "Unset",  # 网格类型
                "version": "",  # 网格版本
                "headsize": 0x0,  # 物体头部大小
                "vertexbytes": 0x0,  # 物体顶点字节
                "uvoffset": 0x0,  # 物体顶点UV数据偏移
            },
            # Prop
            "Prop_V1": {
                "type": "Prop",
                "version": "V1",
                "headsize": 0x1D,
                "vertexbytes": 0x19,
                "uvoffset": 0x10,
            },
            "Prop_V2": {
                "type": "Prop",
                "version": "V2",
                "headsize": 0x21,
                "vertexbytes": 0x1D,
                "uvoffset": 0x10,
            },
            # Map
            "Map_V1": {
                "type": "Map",
                "version": "V1",
                "headsize": 0x1D,
                "vertexbytes": 0x19,
                "uvoffset": 0x10,
            },
            "Map_V2": {
                "type": "Map",
                "version": "V2",
                "headsize": 0x21,
                "vertexbytes": 0x1D,
                "uvoffset": 0x10,
            },
            # Character And Weapon
            "CW_V1": {
                "type": "CW",
                "version": "V1",
                "headsize": 0x1D,
                "vertexbytes": 0x19,
                "uvoffset": 0x8,
            },
            "CW_V2": {
                "type": "CW",
                "version": "V2",
                "headsize": 0x21,
                "vertexbytes": 0x1D,
                "uvoffset": 0x8,
            },
        }

        # 网格头部全局变量
        self.MESH_GVAL = self.MESH_GVAL_CFG["Unset"]

    def extract_name_from_path(self, path: str) -> str:
        """从路径中提取文件名（不包含扩展名）"""
        try:
            return os.path.splitext(os.path.basename(path))[0]
        except Exception:
            return ""

    def read_minpos_maxpos(self, mmap_obj: mmap.mmap) -> bool:
        """读取MinPos MaxPos"""
        try:
            if mmap_obj.size() < self.MINPOS_MAXPOS_SIZE:
                log.debug("MinPos MaxPos数据不足")
                return False

            pos_data = mmap_obj.read(self.MINPOS_MAXPOS_SIZE)
            min_x, min_y, min_z, max_x, max_y, max_z = struct.unpack(
                "<ffffff", pos_data
            )
            log.debug(f"Min Pos: x: {min_x} y: {min_y} z: {min_z}")
            log.debug(f"Max Pos: x: {max_x} y: {max_y} z: {max_z}")

            # 保存MinPos MaxPos数据
            self.min_pos = (min_x, min_y, min_z)
            self.max_pos = (max_x, max_y, max_z)

            return True
        except Exception as e:
            log.error(f"读取MinPos MaxPos失败: {e}")
            return False

    def check_mesh_type_and_version(self, mmap_obj: mmap.mmap):
        """检查网格类型和版本"""
        log.debug("检查网格类型和版本")

        # 保存当前位置
        pos = mmap_obj.tell()

        # 确保有足够的数据可读
        if self.MINPOS_MAXPOS_SIZE + 0x21 >= mmap_obj.size():
            return None

        # Mesh文件头部数据
        head_data = mmap_obj[self.MINPOS_MAXPOS_SIZE : self.MINPOS_MAXPOS_SIZE + 0x21]

        # 尝试读取关键字段
        try:
            # Mesh中包含物体数量
            mesh_obj_count = struct.unpack_from("<I", head_data, 0x0)[0]
            # Mesh中第一个物体包含面数量
            obj_face_count = struct.unpack_from("<I", head_data, 0x4)[0]
            # Mesh中第一个物体包含顶点数量
            obj_vertex_count = struct.unpack_from("<I", head_data, 0x8)[0]
            # Mesh中第一个物体顶点数据大小 - V1版本
            obj_vbyte_v1 = struct.unpack_from("<I", head_data, 0x19)[0]
            # Mesh中第一个物体顶点数据大小 - V2版本
            obj_vbyte_v2 = struct.unpack_from("<I", head_data, 0x1D)[0]

            # 基本验证
            if mesh_obj_count <= 0 or obj_face_count <= 0 or obj_vertex_count <= 0:
                return

            # 判断Mesh版本
            # 类型为 旧版本(V1) Map 或 Prop 文件
            if obj_vbyte_v1 // obj_vertex_count == 0x34:
                if mesh_obj_count > 1:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["Map_V1"]
                    log.debug("判定为 Map V1")
                elif mesh_obj_count == 1:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["Prop_V1"]
                    log.debug("判定为 Prop V1")
            # 类型为 新版本(V2) Map 或 Prop 文件
            elif obj_vbyte_v2 // obj_vertex_count == 0x34:
                if mesh_obj_count > 1:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["Map_V2"]
                    log.debug("判定为 Map V2")
                elif mesh_obj_count == 1:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["Prop_V2"]
                    log.debug("判定为 Prop V2")
            # 可能是角色/武器类型
            else:
                # 可能是 Character / Weapon 文件
                self.MESH_GVAL["type"] = "CW"
                log.debug("判定为 Character / Weapon")

            return self.MESH_GVAL["type"]
        except Exception as e:
            log.debug(f"头部数据解析失败: {e}")
            return None

    def read_obj_header(self, mmap_obj: mmap.mmap):
        """读取物体头部信息,并在首次判断mesh类型"""
        try:
            # 当前位置
            # current_pos = mmap_obj.tell()
            # log.debug(f"current_pos: {hex(current_pos)}")

            # 读取头部数据
            if mmap_obj.tell() + self.MESH_GVAL["headsize"] > mmap_obj.size():
                return None

            # 0x1D Head
            # 15000000 241E0000 483C0000 00000000 02000000 02000000 01A03E0C 00
            # 0x21 Head
            # 70010000 A0010000 40030000 00000000 00000000 00000000 00000000 0000A900 00
            header_data = mmap_obj.read(self.MESH_GVAL["headsize"])
            header = {
                "mesh_obj_count": struct.unpack_from("<I", header_data, 0x0)[0],
                "obj_face_count": struct.unpack_from("<I", header_data, 0x4)[0],
                "obj_vertex_count": struct.unpack_from("<I", header_data, 0x8)[0],
                "obj_vertex_byte": struct.unpack_from(
                    "<I", header_data, self.MESH_GVAL["vertexbytes"]
                )[0],
            }

            # 读取头部数据后的位置
            readed_current_pos = mmap_obj.tell()
            # log.debug(f"readed_current_pos: {hex(readed_current_pos)}")

            # 获取此物体实际面数据占用字节
            try:
                obj_face_size = struct.unpack_from("<I", mmap_obj, readed_current_pos + header["obj_vertex_byte"])[0]
                # log.debug(f"读取完面占用字节后的位置: {hex(mmap_obj.tell())}")
            except Exception as e:
                # log.debug(f"读取面占用字节失败: {e}")
                return None

            # 首次更新总物体数
            if self.MESH_INCLUDE_OBJECT == 0:
                self.MESH_INCLUDE_OBJECT = header["mesh_obj_count"]

            # 验证头部数据
            if (
                # header["mesh_obj_count"] < 0
                header["obj_face_count"] <= 0
                or header["obj_vertex_count"] <= 0
                or header["obj_vertex_byte"] <= 0
                or header["mesh_obj_count"] > header["obj_vertex_byte"]
                or header["obj_face_count"] > header["obj_vertex_count"]
                or header["obj_face_count"] > header["obj_vertex_byte"]
                or header["obj_vertex_count"] > header["obj_vertex_byte"]
                or obj_face_size / 0xc != header["obj_face_count"]
                # 判断实际面数据占用大小是否与头部数据一致！
            ):
                # log.debug("物体头部数据错误")
                return None

            return header
        except Exception as e:
            log.error(f"读取网格头部失败: {e}")
            return None

    def read_vertex(
        self, mmap_obj: mmap.mmap, obj_vertex_count: int, obj_vertex_byte: int
    ):
        """读取顶点数据"""
        try:
            # 读取顶点数据
            obj_v_byte_data = mmap_obj.read(obj_vertex_byte)
            # 每个顶点数据块的大小
            obj_vertex_block_size = obj_vertex_byte // obj_vertex_count

            # 顶点数据返回值
            result = {
                "vertex": [],
                "normals": [],
                "uvs": [],
                "obj_vertex_block_size": obj_vertex_block_size,
            }

            # 读取顶点数据, 法线, UV (数量根据 obj_vertex_count 来确定)
            for i in range(obj_vertex_count):
                # 顶点数据块的偏移位置
                v_offset = obj_vertex_block_size * i
                if v_offset + obj_vertex_block_size > obj_vertex_byte:
                    log.debug("READ_VERTEX: 顶点数据块超出范围")
                    break

                # 顶点
                vx, vy, vz = struct.unpack_from("fff", obj_v_byte_data, v_offset)
                result["vertex"].append((vx, vy, vz))

                # 法线
                nx, ny, nz = struct.unpack_from(
                    "<eee", obj_v_byte_data, v_offset + 0x0C
                )
                result["normals"].append((nx, ny, nz))

                # UV
                uv_offset = (
                    v_offset + obj_vertex_block_size - self.MESH_GVAL["uvoffset"]
                )
                u, v = struct.unpack_from("<ee", obj_v_byte_data, uv_offset)
                result["uvs"].append((u, 1 - v))

            return result
        except Exception as e:
            log.error(f"读取顶点数据失败: {e}")
            return None

    def read_faces(self, mmap_obj: mmap.mmap):
        """读取面数据"""
        try:
            # 获取面数据字节大小
            faces_byte_size = struct.unpack("<I", mmap_obj.read(4))[0]
            faces_byte_data = mmap_obj.read(faces_byte_size)
            # 面数据返回值
            faces = []

            # 读取面数据(12 == 3 * 4 == 3个顶点 * 4字节)
            for i in range(0, faces_byte_size, 12):
                f0, f1, f2 = struct.unpack_from("III", faces_byte_data, i)
                faces.append((f0, f1, f2))

            return faces
        except Exception as e:
            log.error(f"读取面数据失败: {e}")
            return None

    def find_next_head(self, mmap_obj: mmap.mmap, block_size: int) -> bool:
        """逐字节寻找下个物体头部"""

        log.debug(
            f"查找下一个头部: 当前位置: {hex(mmap_obj.tell())}, 块大小: {hex(block_size)}, 总物体数: {hex(self.MESH_INCLUDE_OBJECT)}"
        )

        # 文件大小
        mmap_obj_size = mmap_obj.size()
        # 当前位置
        current_pos = mmap_obj.tell()

        try:
            # 逐字节寻找下个物体头部
            while current_pos + self.MESH_GVAL["headsize"] < mmap_obj_size:
                # 更新当前位置
                current_pos = mmap_obj.tell()

                # 读取头部数据
                header = self.read_obj_header(mmap_obj)

                # 验证初次返回的头部是否有效
                if header is None:
                    # 无效数据，继续寻找
                    mmap_obj.seek(current_pos + 1)
                    continue
                else:
                    # 增强头部校验
                    if (
                        header["obj_vertex_count"] < header["obj_vertex_byte"]
                        and header["obj_vertex_count"] * block_size
                        == header["obj_vertex_byte"]
                        and header["obj_vertex_byte"] + current_pos < mmap_obj_size
                        and (
                            header["mesh_obj_count"] <= self.MESH_INCLUDE_OBJECT
                            and header["mesh_obj_count"] < 8
                            # 防止读取到无效数据, 一般是 0 , 1, 2
                        )
                    ):
                        # 回退位置
                        mmap_obj.seek(current_pos)
                        log.debug(f"找到下一个头部: 位置: {hex(mmap_obj.tell())}")

                        return True
                    else:  # 不是正常的头部数据，继续寻找
                        mmap_obj.seek(current_pos + 1)
                        continue

            log.debug(f"未能找到下一个物体头部地址")
            return False
        except Exception as e:
            log.error(f"寻找下一个物体头部失败: {e}")
            return False

    def read_colormap(
        self, mmap_obj: mmap.mmap, color_start_offset: int, color_end_offset: int
    ):
        """读取贴图信息"""
        try:
            # 获取贴图数据范围
            colors_data = mmap_obj[color_start_offset:color_end_offset]

            # 查找ColorMap标识
            colormap_pos = colors_data.find(b"ColorMap")

            if colormap_pos != -1:
                log.debug(f"找到贴图标识: 偏移量: {hex(colormap_pos)}")

                # 贴图路径长度(0x8 == 8字节 == ColorMap字符串长度)
                path_length = struct.unpack_from("<B", colors_data, colormap_pos + 0x8)[
                    0
                ]

                # 贴图路径(0xC == ColorMap字符串长度 + 4字节贴图路径长度)
                path = colors_data[
                    colormap_pos + 0xC : colormap_pos + 0xC + path_length
                ]

                # 解码路径字符串
                path_str = path.decode("utf-8", errors="replace")

                # 提取贴图名称
                color_map_name = self.extract_name_from_path(path_str)
                log.debug(f"贴图路径: {path_str}, 贴图名称: {color_map_name}")

                return {"path": path_str, "name": color_map_name}
            else:
                log.debug("此物体不包含贴图信息")
                return {"path": "", "name": ""}
        except Exception as e:
            log.error(f"解析贴图数据失败: {e}")
            return {"path": "", "name": ""}

    def process_single_obj(self, mmap_obj: mmap.mmap):
        """处理单个物体数据"""

        # 1. 读取物体头部信息
        header = self.read_obj_header(mmap_obj)
        if not header:
            log.debug("读取物体头部失败")
            return None

        # 2. 读取顶点数据
        vertex_data = self.read_vertex(
            mmap_obj, header["obj_vertex_count"], header["obj_vertex_byte"]
        )
        if not vertex_data:
            log.debug("读取顶点数据失败")
            return None

        # 3. 读取面数据
        faces_data = self.read_faces(mmap_obj)
        if not faces_data:
            log.debug("读取面数据失败")
            return None

        # 4. 读取下一个物体头部位置 与 贴图数据起始位置
        # 贴图数据起始位置
        color_start_offset = mmap_obj.tell()
        # 贴图数据结束位置
        color_end_offset = 0
        next_obj_start = None

        # 根据类型判断是否需要读取下一个物体头部
        if self.MESH_GVAL["type"] == "Map":
            log.debug("读取地图网格数据")
            # 查找下一个物体头部位置
            next_obj_start = self.find_next_head(
                mmap_obj, vertex_data["obj_vertex_block_size"]
            )
            # 贴图数据结束位置
            color_end_offset = mmap_obj.tell()
        elif self.MESH_GVAL["type"] == "Prop":
            log.debug("读取道具网格数据")
            # 贴图数据结束位置
            color_end_offset = mmap_obj.size()

        if next_obj_start is False:
            log.debug(f"未找到下一个物体头部地址, 处理最后一个网格")

        # 读取贴图数据
        colormap = self.read_colormap(mmap_obj, color_start_offset, color_end_offset)

        # 5. 构建并返回物体数据
        return {
            "mesh_obj_number": header["mesh_obj_count"],
            "obj_vertex_count": header["obj_vertex_count"],
            "vertex_data": vertex_data["vertex"],
            "faces_data": faces_data,
            "uvs": vertex_data["uvs"],
            "normals": vertex_data["normals"],
            "colormap": colormap,
        }

    def read_dynamic_head(self, mmap_obj: mmap.mmap):
        """读取头部信息"""
        log.debug(">>> 开始读取头部信息")

        try:
            # 包含的物体名称
            obj_names = []

            # 包含数量 start
            mesh_include_obj_start = struct.unpack("<I", mmap_obj.read(0x4))[0]
            if mesh_include_obj_start == 0:
                log.debug("CW Mesh 包含物体数量为0,跳过读取")
                return {"CANCELLED"}

            # 读取包含的对象名称
            for _ in range(mesh_include_obj_start):
                # 读取物体名称长度
                name_length = struct.unpack("<I", mmap_obj.read(0x4))[0]
                # 读取物体名称
                obj_name = struct.unpack(
                    f"<{name_length}s", mmap_obj.read(name_length)
                )[0].decode("utf-8")
                # log.debug("对象名称: %s", obj_name)
                # 保存名称
                obj_names.append(obj_name)

            # 包含数量 end
            mesh_include_obj_end = struct.unpack("<I", mmap_obj.read(0x4))[0]

            # 检查头部数量是否一致
            if mesh_include_obj_start != mesh_include_obj_end:
                log.debug("! 头部信息解析失败: 包含的对象数量不一致")
                self.report({"ERROR"}, "头部信息解析失败")
                return {"CANCELLED"}

            # 读取物体的 MinPos MaxPos数据(0x18 == minPos(0xC) + maxPos(0xC))
            min_max_data_size = mesh_include_obj_start * 0x18
            min_max_data = mmap_obj.read(min_max_data_size)
            
            # 解析所有物体的MinPos MaxPos数据
            self.bbox_list = []
            for i in range(mesh_include_obj_start):
                offset = i * 0x18
                if offset + 0x18 <= min_max_data_size:
                    min_x, min_y, min_z, max_x, max_y, max_z = struct.unpack(
                        "<ffffff", min_max_data[offset:offset + 0x18]
                    )
                    bbox_data = {
                        'name': obj_names[i] if i < len(obj_names) else f"Object_{i}",
                        'min_pos': (min_x, min_y, min_z),
                        'max_pos': (max_x, max_y, max_z)
                    }
                    self.bbox_list.append(bbox_data)
                    # log.debug(f"CW {bbox_data['name']} - Min: {bbox_data['min_pos']}, Max: {bbox_data['max_pos']}")
            
            # 保存第一个物体的数据（向后兼容）
            if self.bbox_list:
                self.min_pos = self.bbox_list[0]['min_pos']
                self.max_pos = self.bbox_list[0]['max_pos']

            log.debug(f"read_min_max_pos: {hex(min_max_data_size)}, 共 {len(self.bbox_list)} 个边界框")

            # 返回 物体开始位置，物体信息
            return obj_names
        except Exception as e:
            log.debug("! 读取头部信息失败: %s", e)
            self.report({"ERROR"}, "读取头部信息失败")
            return {"CANCELLED"}

    def check_cw_mesh_version(self, mmap_obj: mmap.mmap):
        """检查CW Mesh 版本"""
        log.debug(">>> 开始检查CW Mesh 版本")
        # 保存当前位置
        pos = mmap_obj.tell()

        # Mesh文件头部数据
        head_data = mmap_obj[pos : pos + 0x21]

        # 尝试读取关键字段
        try:
            # obj数量
            obj_count = struct.unpack_from("<I", head_data, 0x0)[0]
            # Mesh中第一个物体包含面数量
            obj_face_count = struct.unpack_from("<I", head_data, 0x4)[0]
            # Mesh中第一个物体包含顶点数量
            obj_vertex_count = struct.unpack_from("<I", head_data, 0x8)[0]
            # Mesh中第一个物体顶点数据大小 - V1版本
            obj_vbyte_v1 = struct.unpack_from("<I", head_data, 0x19)[0]
            # Mesh中第一个物体顶点数据大小 - V2版本
            obj_vbyte_v2 = struct.unpack_from("<I", head_data, 0x1D)[0]

            # 基本验证
            if obj_count <= 0 or obj_face_count <= 0 or obj_vertex_count <= 0:
                return

            # 面数据字节大小
            face_byte_size = obj_face_count * 0xC

            # 判断Mesh版本
            # 类型为 旧版本(V1) Mesh 文件(0x40 == 每组顶点数据字节大小)
            if obj_vbyte_v1 // obj_vertex_count == 0x40:
                # 从当前物体中获取面数据大小 (0x1D == V1版本的头部大小)
                get_face_byte = mmap_obj[
                    pos + 0x1D + obj_vbyte_v1 : pos + 0x1D + obj_vbyte_v1 + 0x4
                ]
                get_face_byte_size = struct.unpack("<I", get_face_byte)[0]
                log.debug(f"get_face_size : {get_face_byte}")

                # 验证计算出的面字节和实际读取到的面字节大小是否一致
                if get_face_byte_size == face_byte_size:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["CW_V1"]
                    log.debug("判定为 CW V1")
                else:
                    log.debug("------------ 不是 CW V1 或 V2 ------------")
            # 类型为 新版本(V2) Mesh 文件
            elif obj_vbyte_v2 // obj_vertex_count == 0x40:
                # 从当前物体中获取面数据大小 (0x21 == V2版本的头部大小)
                get_face_byte = mmap_obj[
                    pos + 0x21 + obj_vbyte_v2 : pos + 0x21 + obj_vbyte_v2 + 0x4
                ]
                get_face_byte_size = struct.unpack("<I", get_face_byte)[0]

                # 验证计算出的面字节和实际读取到的面字节大小是否一致
                if get_face_byte_size == face_byte_size:
                    self.MESH_GVAL = self.MESH_GVAL_CFG["CW_V2"]
                    log.debug("判定为 CW V2")
                else:
                    log.debug("------------ 不是 CW V2 或 V1 ------------")

            # 首次更新总物体数
            if self.MESH_INCLUDE_OBJECT == 0:
                self.MESH_INCLUDE_OBJECT = obj_count

            return self.MESH_GVAL["version"]
        except Exception as e:
            log.debug(f"头部数据解析失败: {e}")
            return None

    def read_cw_head(self, mmap_obj: mmap.mmap):
        """读取人物或武器头部信息"""
        log.debug(">>> 开始读取头部信息")

        header_data = mmap_obj.read(self.MESH_GVAL["headsize"])

        # 本物体包含网格物体数量
        header = {
            "mesh_obj_count": struct.unpack_from("<I", header_data, 0x0)[0],
            "obj_face_count": struct.unpack_from("<I", header_data, 0x4)[0],
            "obj_vertex_count": struct.unpack_from("<I", header_data, 0x8)[0],
            "obj_vertex_byte": struct.unpack_from(
                "<I", header_data, self.MESH_GVAL["vertexbytes"]
            )[0],
        }

        # todo: 验证数据是否有效

        # 返回文件中包含网格物体数量, 本物体面数据组数量, 本网格变换矩阵数量, 本网格字节总数
        return header

    def read_cw_vertex(
        self, mmap_obj: mmap.mmap, obj_vertex_count: int, obj_vertex_byte: int
    ):
        """读取人物或武器顶点数据"""
        log.debug(">>> 开始读CW取顶点数据")
        try:
            # 每个顶点数据块的大小
            block_size = obj_vertex_byte // obj_vertex_count

            # 读取顶点数据
            vertex_data = mmap_obj.read(obj_vertex_byte)

            # 顶点数据返回值
            res_data = {
                "vertex": [],
                "normals": [],
                "uv": [],
                "block_size": block_size,
            }

            for i in range(obj_vertex_count):
                # 计算当前块的起始位置
                v_offset = block_size * i
                # 确保有足够的字节进行解包
                if v_offset + block_size <= obj_vertex_byte:
                    # 顶点
                    vx, vy, vz = struct.unpack_from("fff", vertex_data, v_offset)
                    # 将顶点添加到顶点列表
                    res_data["vertex"].append((vx, vy, vz))

                    # 法线​​
                    nx, ny, nz = struct.unpack_from(
                        "<eee", vertex_data, v_offset + 0x0C
                    )
                    res_data["normals"].append((nx, ny, nz))

                    # UV
                    uv_offset = v_offset + block_size - self.MESH_GVAL["uvoffset"]
                    u, v = struct.unpack_from("<ee", vertex_data, uv_offset)
                    res_data["uv"].append((u, 1 - v))

                else:
                    log.debug("! 顶点数据解析失败: 不足的字节数在偏移量 %s", v_offset)
                    break

            return res_data
        except Exception as e:
            log.debug("! 顶点CW数据解析失败: %s", e)
            # self.report({"ERROR"}, f"顶点CW数据解析失败 : {e}")
            # return {"CANCELLED"}
            return None

    def read_cw_faces(self, mmap_obj: mmap.mmap):
        """读取CW面数据"""
        log.debug(">>> 开始读取CW面数据")
        # 获取面数据字节大小
        face_byte_size = struct.unpack("<I", mmap_obj.read(0x4))[0]
        # 获取面数据
        faces_data = mmap_obj.read(face_byte_size)
        # 面数据返回值
        res_faces = []

        try:
            # 确保有足够的字节进行解包
            for i in range(0, face_byte_size, 12):
                f0, f1, f2 = struct.unpack_from("III", faces_data, i)
                res_faces.append((f0, f1, f2))

            return res_faces
        except Exception as e:
            log.debug("! 面数据解析失败: %s", e)
            self.report({"ERROR"}, f"面数据解析失败 : {e}")
            # traceback.print_exc()
            # return {"CANCELLED"}
            return None

    def process_character_weapon(self, mmap_obj: mmap.mmap):
        """处理人物和武器Mesh"""
        log.debug("处理人物和武器Mesh")

        # 对象数据
        mesh_obj = []

        try:
            # 读取动态头部,获取包含的物体名称
            obj_namess = self.read_dynamic_head(mmap_obj)

            # 判断CW Mesh 版本
            check_cw_version = self.check_cw_mesh_version(mmap_obj)
            if check_cw_version is None:
                log.debug("无法判断CW版本")
                return None

            # 依次处理每个物体
            while self.MESH_OBJECT_READED < self.MESH_INCLUDE_OBJECT:
                log.debug(">>> 读取网格信息名称")

                # 读取头部信息
                head_data = self.read_cw_head(mmap_obj)

                if head_data is None:
                    log.debug("! 读取头部信息失败")
                    break

                # 解析顶点数据块
                vertex_data = self.read_cw_vertex(
                    mmap_obj,
                    head_data["obj_vertex_count"],
                    head_data["obj_vertex_byte"],
                )

                # 判断是否读取失败
                if vertex_data is None:
                    log.debug("! 解析顶点数据失败")
                    # return mesh_obj
                    break

                # 获取面数据
                face_data = self.read_cw_faces(mmap_obj)

                # 判断是否读取失败
                if face_data is None:
                    log.debug("! 解析面数据失败")
                    # return mesh_obj
                    break

                # 贴图数据起始位置
                color_start_offset = mmap_obj.tell()
                # 贴图数据结束位置
                color_end_offset = 0
                next_obj_start = None

                # 根据Mesh包含数量判断是否需要读取下一个物体头部
                if self.MESH_INCLUDE_OBJECT > 1:
                    if self.MESH_OBJECT_READED < self.MESH_INCLUDE_OBJECT:
                        log.debug("读取下一个CW物体头部位置")
                        # 查找下一个物体头部位置
                        next_obj_start = self.find_next_head(
                            mmap_obj, vertex_data["block_size"]
                        )
                        color_end_offset = mmap_obj.tell()
                    else:
                        log.debug("不需要读取下一个CW物体头部位置")
                        color_end_offset = mmap_obj.size()
                elif self.MESH_INCLUDE_OBJECT == 1:
                    log.debug("不需要读取下一个CW物体头部位置")
                    color_end_offset = mmap_obj.size()

                if next_obj_start is False:
                    log.debug(f"未找到下一个物体头部地址, 处理最后一个网格")

                # 查找ColorMap
                colormap = self.read_colormap(
                    mmap_obj, color_start_offset, color_end_offset
                )

                # 向mesh_obj中添加数据
                mesh_obj.append(
                    {
                        "mesh_obj_number": head_data["mesh_obj_count"],
                        "obj_vertex_count": head_data["obj_vertex_count"],
                        "vertex_data": vertex_data["vertex"],
                        "faces_data": face_data,
                        "uvs": vertex_data["uv"],
                        "normals": vertex_data["normals"],
                        "colormap": colormap,
                    }
                )

                self.MESH_OBJECT_READED += 1

            return mesh_obj, obj_namess
        except Exception as e:
            log.debug("! 分割网格数据失败: %s", e)
            # traceback.print_exc()
            return mesh_obj, None

    def parse_file(self, filepath: str) -> list:
        """解析网格文件"""
        self.reset()
        results = []

        try:
            with open(filepath, "rb") as f:
                with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mmap_obj:

                    # 首次读取头部数据时，尝试判断网格类型与版本
                    if self.MESH_GVAL["type"] == "Unset":
                        check_type = self.check_mesh_type_and_version(mmap_obj)
                        if check_type is None:
                            log.debug("无法判断网格类型")
                            return None

                    # 处理人物和武器Mesh
                    if self.MESH_GVAL["type"] == "CW":
                        log.debug("判定为 Character")
                        read_mesh_obj, obj_namess = self.process_character_weapon(
                            mmap_obj
                        )
                        if read_mesh_obj is None:
                            log.debug("读取人物或武器Mesh失败")
                        else:
                            results = read_mesh_obj

                    # 处理地图和道具Mesh
                    else:
                        log.debug("判定为 Prop / Map")

                        # 1. 读取并验证MinPos MaxPos
                        if not self.read_minpos_maxpos(mmap_obj):
                            log.debug("读取MinPos MaxPos失败,或非有效网格文件!")
                            return None

                        # 2. 处理单个物体
                        while mmap_obj.tell() < mmap_obj.size():
                            # 读取并处理单个物体
                            obj_data = self.process_single_obj(mmap_obj)

                            # 检查是否读取到有效数据
                            if obj_data is None:
                                log.debug("读取物体数据失败，停止解析")
                                break

                            results.append(obj_data)
                            self.MESH_OBJECT_READED += 1

                            log.debug(
                                f"已处理 {self.MESH_OBJECT_READED} 个物体, 共 {self.MESH_INCLUDE_OBJECT} 个"
                            )

                            # 如果已经处理完所有物体，退出循环
                            if self.MESH_OBJECT_READED >= self.MESH_INCLUDE_OBJECT:
                                log.debug("已处理完所有物体，停止解析")
                                break

                log.info(
                    f"成功解析 {len(results)} 个网格对象，类型: {self.MESH_GVAL['type']}, 版本: {self.MESH_GVAL['version']}"
                )
                return results
        except Exception as e:
            log.error(f"文件解析失败: {e}")
            return []
