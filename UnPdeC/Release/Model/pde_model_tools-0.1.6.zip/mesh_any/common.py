# common.py
import bpy
import bmesh
import math
import os
from typing import Set
from ..log import log

# 旋转角度
ROTATION_X = math.radians(90)
# 默认 UV 层名称
DEFAULT_UV_LAYER = "UVMap"
# Colormap 节点名称
COLORMAP_NODE_NAME = "Colormap"
# BSDF 节点名称
BSDF_NODE_NAME = "Principled BSDF"
# Alpha 模式
# 'CHANNEL_PACKED' - 通道打包
# 'STRAIGHT' - 直接
# 'PREMUL' - 预乘
# 'NONE' - 无alpha通道
ALPHA_MODE = "CHANNEL_PACKED"


def create_uvs(mesh: bpy.types.Mesh, uvs: list) -> None:
    """创建 UV 映射"""
    uv_layer = mesh.uv_layers.new(name=DEFAULT_UV_LAYER)
    for poly in mesh.polygons:
        for loop_idx in poly.loop_indices:
            vert_idx = mesh.loops[loop_idx].vertex_index
            uv_coord = uvs[vert_idx] if vert_idx < len(uvs) else (0.0, 0.0)
            uv_layer.data[loop_idx].uv = uv_coord


def create_normals(mesh: bpy.types.Mesh, normals: list) -> None:
    """创建法线"""
    # todo: 似乎没用！！！
    loop_normals = []
    for poly in mesh.polygons:
        for v in poly.vertices:
            normal = normals[v] if v < len(normals) else (0.0, 0.0, 1.0)
            loop_normals.append(normal)
    mesh.normals_split_custom_set(loop_normals)


def setup_transform(obj: bpy.types.Object) -> None:
    """设置对象变换"""
    obj.rotation_mode = "XYZ"
    obj.rotation_euler = (ROTATION_X, 0, 0)


def create_material(
    colormap_name: str, texture_path: str, mesh_type: str = "Unset"
) -> bpy.types.Material:
    """创建材质，根据网格类型应用不同的材质设置"""
    mat = bpy.data.materials.new(name=colormap_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    # 创建节点
    bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
    bsdf.name = BSDF_NODE_NAME
    bsdf.location = (0, 0)

    # 应用材质设置
    bsdf.inputs["IOR"].default_value = 1.0  # 设置折射率为1.0

    tex_node = nodes.new(type="ShaderNodeTexImage")
    tex_node.name = COLORMAP_NODE_NAME
    tex_node.location = (-300, 0)

    # 加载纹理文件
    if os.path.exists(texture_path):
        tex_node.image = bpy.data.images.load(texture_path, check_existing=True)
        # 设置Alpha模式为通道打包
        tex_node.image.alpha_mode = ALPHA_MODE
    else:
        log.debug(f"CREATE_MATERIAL: 贴图文件不存在")

    output = nodes.new(type="ShaderNodeOutputMaterial")
    output.location = (300, 0)

    # 连接节点
    links.new(bsdf.inputs["Base Color"], tex_node.outputs["Color"])
    links.new(output.inputs["Surface"], bsdf.outputs["BSDF"])

    return mat


def setup_material(
    obj: bpy.types.Object,
    colormap_name: str,
    colormap_path: str,
    dir_path: str,
    processed_materials: Set[str],
    mesh_type: str = "Unset",
) -> None:
    """设置材质并处理路径"""
    # 标准化路径
    normalized_path = os.path.normpath(colormap_path.lstrip("/").replace("/", os.sep))
    dds_full_path = os.path.join(dir_path, normalized_path)

    # 获取或创建材质
    material_key = f"{colormap_name}_{mesh_type}"
    if material_key in processed_materials:
        mat = bpy.data.materials[colormap_name]
    else:
        mat = create_material(colormap_name, dds_full_path, mesh_type)
        processed_materials.add(material_key)

    # 分配材质
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def build_geometry(mesh: bpy.types.Mesh, mesh_data) -> None:
    """构建网格几何体"""
    mesh.from_pydata(mesh_data["vertex_data"], [], mesh_data["faces_data"])
    create_uvs(mesh, mesh_data["uvs"])
    create_normals(mesh, mesh_data["normals"])
    mesh.update()


def create_mesh_object(
    context: bpy.types.Context,
    mesh_data,
    base_name: str,
    index: int,
    processed_materials: Set[str],
    dir_path: str,
    mesh_type: str = "Unset",
) -> bpy.types.Object:
    """创建网格对象"""
    name = f"{base_name}_{index}"
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)

    # 链接到场景并构建
    context.collection.objects.link(obj)
    build_geometry(mesh, mesh_data)
    setup_transform(obj)

    # 设置材质
    if mesh_data["colormap"]["name"]:
        setup_material(
            obj,
            mesh_data["colormap"]["name"],
            mesh_data["colormap"]["path"],
            dir_path,
            processed_materials,
            mesh_type,
        )

    return obj


def create_bounding_box(
    context: bpy.types.Context,
    min_pos: tuple,
    max_pos: tuple,
    base_name: str
) -> bpy.types.Object:
    """创建边界框线框对象"""
    try:
        bbox_name = f"BBox_{base_name}"
        
        # 删除之前的边界框（如果存在）
        old_bbox = bpy.data.objects.get(bbox_name)
        if old_bbox:
            bpy.data.objects.remove(old_bbox, do_unlink=True)
        
        # 创建新的网格
        mesh = bpy.data.meshes.new(bbox_name)
        obj = bpy.data.objects.new(bbox_name, mesh)
        
        # 链接到场景
        context.collection.objects.link(obj)
        
        # 创建bmesh
        bm = bmesh.new()
        
        # 定义立方体的8个顶点
        vertices = [
            (min_pos[0], min_pos[1], min_pos[2]),  # 0: min_x, min_y, min_z
            (max_pos[0], min_pos[1], min_pos[2]),  # 1: max_x, min_y, min_z
            (max_pos[0], max_pos[1], min_pos[2]),  # 2: max_x, max_y, min_z
            (min_pos[0], max_pos[1], min_pos[2]),  # 3: min_x, max_y, min_z
            (min_pos[0], min_pos[1], max_pos[2]),  # 4: min_x, min_y, max_z
            (max_pos[0], min_pos[1], max_pos[2]),  # 5: max_x, min_y, max_z
            (max_pos[0], max_pos[1], max_pos[2]),  # 6: max_x, max_y, max_z
            (min_pos[0], max_pos[1], max_pos[2]),  # 7: min_x, max_y, max_z
        ]
        
        # 添加顶点到bmesh
        for v in vertices:
            bm.verts.new(v)
        
        # 确保顶点索引有效
        bm.verts.ensure_lookup_table()
        
        # 定义立方体的12条边
        edges = [
            # 底面 (z = min_z)
            (0, 1), (1, 2), (2, 3), (3, 0),
            # 顶面 (z = max_z)
            (4, 5), (5, 6), (6, 7), (7, 4),
            # 垂直边
            (0, 4), (1, 5), (2, 6), (3, 7)
        ]
        
        # 添加边到bmesh
        for edge in edges:
            bm.edges.new([bm.verts[edge[0]], bm.verts[edge[1]]])
        
        # 更新网格
        bm.to_mesh(mesh)
        bm.free()
        
        # 设置显示模式为线框
        obj.display_type = 'WIRE'
        
        # 创建红色发光材质
        mat = bpy.data.materials.new(name=f"{bbox_name}_Material")
        mat.use_nodes = True
        
        # 清除默认节点
        mat.node_tree.nodes.clear()
        
        # 添加输出节点
        output_node = mat.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
        output_node.location = (300, 0)
        
        # 添加发射着色器节点
        emission_node = mat.node_tree.nodes.new(type='ShaderNodeEmission')
        emission_node.location = (0, 0)
        emission_node.inputs['Color'].default_value = (1.0, 0.2, 0.2, 1.0)  # 红色
        emission_node.inputs['Strength'].default_value = 1.5
        
        # 连接节点
        mat.node_tree.links.new(emission_node.outputs['Emission'], output_node.inputs['Surface'])
        
        # 应用材质
        obj.data.materials.append(mat)
        
        # 应用旋转变换（与网格对象保持一致）
        setup_transform(obj)
        
        # log.info(f"创建边界框: {bbox_name}, Min{min_pos}, Max{max_pos}")
        
        return obj
        
    except Exception as e:
        log.error(f"创建边界框失败: {e}")
        return None
