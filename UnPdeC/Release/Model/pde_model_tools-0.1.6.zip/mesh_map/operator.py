"""
mesh_map.operator
~~~~~~~~~~~~~~~~

用于导入和处理地图网格数据。
"""

import os
import math
import bpy
from typing import List, Set
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty
from bpy.types import Operator
from . import utils
from ..log import log
from .. import MAIN_PACKAGE

# 常量定义
ROTATION_X = math.radians(90)
DEFAULT_UV_LAYER = "UVMap"
COLORMAP_NODE_NAME = "Colormap"
BSDF_NODE_NAME = "Principled BSDF"


def create_uvs(mesh: bpy.types.Mesh, uvs: list) -> None:
    """创建 UV 映射"""
    uv_layer = mesh.uv_layers.new(name=DEFAULT_UV_LAYER)
    for poly in mesh.polygons:
        for loop_idx in poly.loop_indices:
            vert_idx = mesh.loops[loop_idx].vertex_index
            uv_coord = uvs[vert_idx] if vert_idx < len(uvs) else (0.0, 0.0)
            uv_layer.data[loop_idx].uv = uv_coord


def create_normals(mesh: bpy.types.Mesh, normals: list) -> None:
    """创建法线"""
    loop_normals = []
    for poly in mesh.polygons:
        for v in poly.vertices:
            normal = normals[v] if v < len(normals) else (0.0, 0.0, 1.0)
            loop_normals.append(normal)
    mesh.normals_split_custom_set(loop_normals)


def setup_transform(obj: bpy.types.Object) -> None:
    """设置对象变换"""
    obj.rotation_mode = "XYZ"
    obj.rotation_euler = (ROTATION_X, 0, 0)


def create_material(colormap_name: str, texture_path: str) -> bpy.types.Material:
    """创建材质"""
    mat = bpy.data.materials.new(name=colormap_name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    # 创建节点
    bsdf = nodes.new(type="ShaderNodeBsdfPrincipled")
    bsdf.name = BSDF_NODE_NAME
    bsdf.location = (0, 0)

    bsdf.inputs["IOR"].default_value = 1.0  # 设置折射率为1.0

    tex_node = nodes.new(type="ShaderNodeTexImage")
    tex_node.name = COLORMAP_NODE_NAME
    tex_node.location = (-300, 0)
    tex_node.image = bpy.data.images.get(colormap_name)

    # 加载纹理文件
    if os.path.exists(texture_path):
        tex_node.image = bpy.data.images.load(texture_path, check_existing=True)
        # 设置Alpha模式为通道打包
        tex_node.image.alpha_mode = "PREMUL"
        # 'CHANNEL_PACKED' - 通道打包
        # 'STRAIGHT' - 直接
        # 'PREMUL' - 预乘
        # 'NONE' - 无alpha通道
        log.debug(f"CREATE_MATERIAL: 成功加载纹理: {colormap_name}")
    else:
        # 文件不存在，创建占位图像
        log.error(f"贴图文件不存在: {colormap_name}")
        # tex_node.image = bpy.data.images.new(colormap_name, 1, 1)  # 1x1像素图像
        # tex_node.image.generated_color = (1.0, 0.0, 1.0, 1.0)  # 紫色占位符

    output = nodes.new(type="ShaderNodeOutputMaterial")
    output.location = (300, 0)

    # 连接节点
    links.new(bsdf.inputs["Base Color"], tex_node.outputs["Color"])
    links.new(output.inputs["Surface"], bsdf.outputs["BSDF"])

    return mat


def setup_material(
    obj: bpy.types.Object,
    colormap_name: str,
    colormap_path: str,
    dir_path: str,
    processed_materials: Set[str],
) -> None:
    """设置材质"""

    # 转换Unix路径为Windows路径
    unix_path = colormap_path.lstrip("/")  # 去掉开头的斜杠
    windows_relative_path = unix_path.replace("/", "\\")  # 替换斜杠方向
    dds_full_path = os.path.join(dir_path, windows_relative_path)  # 拼接完整路径
    # log.debug(f"完整路径: {dds_full_path}")

    # 检查文件是否存在
    if not os.path.exists(dds_full_path):
        log.error(f"贴图文件不存在: {dds_full_path}")

    # 获取或创建材质
    mat = None
    if colormap_name in bpy.data.materials:
        mat = bpy.data.materials[colormap_name]
    elif colormap_name in processed_materials:
        mat = bpy.data.materials[colormap_name]
    else:
        mat = create_material(colormap_name, dds_full_path)
        processed_materials.add(colormap_name)

    # 分配材质
    if obj.data.materials:
        obj.data.materials[0] = mat
    else:
        obj.data.materials.append(mat)


def build_geometry(mesh: bpy.types.Mesh, mesh_data: utils.TMeshData) -> None:
    """构建网格几何体"""
    mesh.from_pydata(mesh_data.vertex_data, [], mesh_data.faces_data)
    create_uvs(mesh, mesh_data.uvs)
    create_normals(mesh, mesh_data.normals)
    mesh.update()


def create_mesh_object(
    context: bpy.types.Context,
    mesh_data: utils.TMeshData,
    base_name: str,
    index: int,
    processed_materials: Set[str],
) -> bpy.types.Object:
    """创建网格对象"""
    # 创建网格
    name = f"{base_name}_{index}"
    mesh = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, mesh)

    # 链接到场景并构建
    context.collection.objects.link(obj)
    build_geometry(mesh, mesh_data)
    setup_transform(obj)

    # 获取游戏资源路径
    dir_path = context.preferences.addons[MAIN_PACKAGE].preferences.dir_path

    # 设置材质
    if mesh_data.colormap.name:
        setup_material(
            obj,
            mesh_data.colormap.name,
            mesh_data.colormap.path,
            dir_path,
            processed_materials,
        )

    return obj


class PMT_OT_MeshMap(Operator, ImportHelper):
    """导入地图.mesh文件 \n Import map .mesh file"""

    bl_idname = "pmt.mesh_map"
    bl_label = "Map Mesh"
    bl_options = {"REGISTER", "UNDO"}

    # 筛选文件类型
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})  # type: ignore

    def execute(self, context: bpy.types.Context) -> Set[str]:
        try:
            # 检查文件路径
            if not os.path.exists(self.filepath):
                self.report({"ERROR"}, "文件路径不存在")
                return {"CANCELLED"}

            # 读取并处理网格文件 -> utils
            mesh_objects: List[utils.TMeshData] = utils.read_mesh_func(self.filepath)

            if not mesh_objects:
                self.report({"ERROR"}, "未能读取到有效的网格数据,Mesh文件可能损坏！")
                return {"CANCELLED"}

            # 获取基础名称并处理
            base_name = os.path.splitext(os.path.basename(self.filepath))[0]
            processed_materials = set()
            imported_count = 0

            # 处理每个网格对象
            for idx, mesh_data in enumerate(mesh_objects, 1):
                if not mesh_data.normals or len(mesh_data.normals) != len(
                    mesh_data.vertex_data
                ):
                    log.error(f"跳过网格 {idx}: 法线​​数据不匹配")
                    continue

                # 创建网格对象
                create_mesh_object(
                    context, mesh_data, base_name, idx, processed_materials
                )
                imported_count += 1

            log.info(f"成功导入 {imported_count} 个物体, 共 {utils.MESH_FRIST_OBJECT_COUNT} 个物体")

            self.report(
                {"INFO"},
                f"成功导入 {imported_count} 个物体, 共 {utils.MESH_FRIST_OBJECT_COUNT} 个物体",
            )

            # 重置全局变量
            utils.rest_global_val()
            
            return {"FINISHED"}
        except Exception as e:
            log.error(f"操作失败: {e}", exc_info=True)
            self.report({"ERROR"}, f"严重错误: {str(e)}")
            return {"CANCELLED"}
