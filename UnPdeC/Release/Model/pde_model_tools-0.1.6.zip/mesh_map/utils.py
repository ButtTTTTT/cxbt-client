"""
mesh_map.utils
~~~~~~~~~~~~~

提供网格文件解析和处理的核心功能。
"""

import mmap
import struct
from typing import List, Tuple, Optional, NamedTuple, TypedDict
from ..log import log

# "常量"
# MinPos MaxPos数据大小
MINPOS_MAXPOS_SIZE = 0x18
# 物体顶点数据中UV数据位置
OBJ_VERTEX_UV_OFFSET = 0x10
# 物体头部配置
OBJ_HEAD_CONFIG = {
    "UNSET": {
        "type": "UNSET",
        "size": 0,  # 头部大小
        "vertex_offset": 0,  # 物体头中顶点总字节开始位置
    },
    "T1": {
        "type": "T1",
        "size": 0x1D,  # 头部大小
        "vertex_offset": 0x19,  # 物体头中顶点总字节开始位置
    },
    "T2": {
        "type": "T2",
        "size": 0x21,  # 头部大小
        "vertex_offset": 0x1D,  # 物体头中顶点总字节开始位置
    },
}


# 变量
# 网格第一个物体中包含的子物体数量
MESH_FRIST_OBJECT_COUNT = 0x0
# 已读取物体数量
MESH_OBJECT_READED = 0x0
# 物体动态头部(默认为UNSET)
OBJ_HEAD = {}


# 数据类型
class TObjHeader(TypedDict):
    """每个物体头部数据结构"""

    obj_include_count: int  # 偏移 0x0，表示此物体中 包含的子物体数量
    obj_face_groups_count: int  # 偏移 0x4，表示面的组数量
    obj_vertex_count: int  # 偏移 0x8，表示顶点的组数量
    obj_vertex_byte: int  # 偏移 OBJ_HEADER_VERTEX_OFFSET，表示顶点数据的字节大小


class TVertexData(TypedDict):
    """顶点数据结构"""

    vertex: List[Tuple[float, float, float]]  # 三维顶点坐标 (x,y,z)
    normals: List[Tuple[float, float, float]]  # 三维法线​​量 (nx,ny,nz)
    uvs: List[Tuple[float, float]]  # 二维纹理坐标 (u,v)
    obj_vertex_block_size: int  # 单个顶点数据块的大小（字节数）


class TColorMapData(NamedTuple):
    """贴图数据结构"""

    path: str = ""  # 贴图路径
    name: str = ""  # 贴图名称


class TMeshData(NamedTuple):
    """网格数据结构"""

    mesh_obj_number: int = 0  # 包含物体数
    obj_vertex_count: int = 0  # 有多少组顶点
    vertex_data: List[Tuple[float, float, float]] = []  # 顶点数据
    faces_data: List[Tuple[int, int, int]] = []  # 面数据
    uvs: List[Tuple[float, float]] = []  # UV数据
    normals: List[Tuple[float, float, float]] = []  # 法线​​量数据
    colormap: TColorMapData = TColorMapData()  # 贴图数据


def print_gval():
    log.debug("------------------------------全局变量-----------------------------")
    global MINPOS_MAXPOS_SIZE, OBJ_VERTEX_UV_OFFSET, OBJ_HEAD, OBJ_HEAD_CONFIG, MESH_FRIST_OBJECT_COUNT, MESH_OBJECT_READED
    log.debug(f"MINPOS_MAXPOS_SIZE: {MINPOS_MAXPOS_SIZE}")
    log.debug(f"OBJ_VERTEX_UV_OFFSET: {OBJ_VERTEX_UV_OFFSET}")
    log.debug(f"MESH_FRIST_OBJECT_COUNT: {MESH_FRIST_OBJECT_COUNT}")
    log.debug(f"MESH_OBJECT_READED: {MESH_OBJECT_READED}")
    log.debug(f"OBJ_HEAD_CONFIG: {OBJ_HEAD_CONFIG}")
    log.debug(f"OBJ_HEAD: {OBJ_HEAD}")
    log.debug("-----------------------------------------------------------------")


def rest_global_val():
    log.debug("-----------------------重置全局变量----------------------------------")
    global MINPOS_MAXPOS_SIZE, OBJ_VERTEX_UV_OFFSET, OBJ_HEAD, OBJ_HEAD_CONFIG, MESH_FRIST_OBJECT_COUNT, MESH_OBJECT_READED
    MESH_FRIST_OBJECT_COUNT = 0x0  # 网格第一个物体中包含的子物体数量
    MESH_OBJECT_READED = 0x0  # 已读取物体数量
    OBJ_HEAD = OBJ_HEAD_CONFIG["UNSET"]  # 物体动态头部(默认为UNSET)
    print_gval()


def extract_name_from_path(path: str) -> str:
    """从路径中提取文件名（不包含扩展名）"""
    try:
        file_name = path.split("/")[-1]
        return file_name.split(".")[0]
    except Exception:
        return ""


def read_minpos_maxpos(mmap_obj: mmap.mmap) -> bool:
    """读取MinPos MaxPos"""
    try:
        # 判断数据是否足够
        if mmap_obj.size() < MINPOS_MAXPOS_SIZE:
            log.debug("MinPos MaxPos 数据不足")
            return False

        # 读取MinPos MaxPos
        pos_data = mmap_obj.read(MINPOS_MAXPOS_SIZE)
        min_x, min_y, min_z, max_x, max_y, max_z = struct.unpack("<ffffff", pos_data)

        log.debug(f"Min Pos: x: {min_x} y: {min_y} z: {min_z}")
        log.debug(f"Max Pos: x: {max_x} y: {max_y} z: {max_z}")

        return True
    except Exception as e:
        log.debug(f"读取MinPos MaxPos失败: {e}")
        return False


def read_obj_header(mmap_obj: mmap.mmap) -> Optional[TObjHeader]:
    """读取物体头部信息"""
    try:
        global OBJ_HEAD, OBJ_HEAD_CONFIG, MESH_FRIST_OBJECT_COUNT

        # 判断OBJ头部类型(因为头部大小不一样!)
        if OBJ_HEAD["type"] == "UNSET":
            log.debug("未读取到头部类型")

            # 读取头部数据
            head_tmp_data = mmap_obj[mmap_obj.tell() : mmap_obj.tell() + 0x21]
            tead_tmp = {
                # 这个位置是顶点数据又多少组
                "tmp_vertex_count": struct.unpack_from("<I", head_tmp_data, 0x8)[0],
                # 旧版本的头部有 0x19+ 0x4 = 0x1D字节
                "tmp_vertex_byte_t1": struct.unpack_from("<I", head_tmp_data, 0x19)[0],
                # 新版本的头部有 0x1D+ 0x4 = 0x21字节
                "tmp_vertex_byte_t2": struct.unpack_from("<I", head_tmp_data, 0x1D)[0],
            }

            # 判断头部类型
            if tead_tmp["tmp_vertex_byte_t2"] // tead_tmp["tmp_vertex_count"] == 0x34:
                log.debug("读取到头部类型 T2")
                OBJ_HEAD = OBJ_HEAD_CONFIG["T2"]
            elif tead_tmp["tmp_vertex_byte_t1"] // tead_tmp["tmp_vertex_count"] == 0x34:
                log.debug("读取到头部类型 T1")
                OBJ_HEAD = OBJ_HEAD_CONFIG["T1"]

        # 判断数据是否足够
        if mmap_obj.tell() + OBJ_HEAD["size"] >= mmap_obj.size():
            # log.debug("物体头部数据不足")
            return None

        # 读取物体头部数据
        obj_header_data = mmap_obj.read(OBJ_HEAD["size"])
        header: TObjHeader = {
            "obj_include_count": struct.unpack_from("<I", obj_header_data, 0x0)[0],
            "obj_face_groups_count": struct.unpack_from("<I", obj_header_data, 0x4)[0],
            "obj_vertex_count": struct.unpack_from("<I", obj_header_data, 0x8)[0],
            "obj_vertex_byte": struct.unpack_from(
                "<I", obj_header_data, OBJ_HEAD["vertex_offset"]
            )[0],
        }

        # 首次更新总物体数
        if MESH_FRIST_OBJECT_COUNT == 0:
            MESH_FRIST_OBJECT_COUNT = header["obj_include_count"]

        # 检查读取到的header数据是否正确
        if (
            header["obj_include_count"] < 0
            or header["obj_face_groups_count"] <= 0
            or header["obj_vertex_count"] <= 0
            or header["obj_vertex_byte"] <= 0
            or header["obj_include_count"] > header["obj_vertex_byte"]
            or header["obj_face_groups_count"] > header["obj_vertex_count"]
            or header["obj_face_groups_count"] > header["obj_vertex_byte"]
            or header["obj_vertex_count"] > header["obj_vertex_byte"]
        ):
            # log.debug("物体头部数据错误")
            return None

        # log.debug(
        #     "物体数量: %s 面组数量: %s 顶点数量: %s 顶点字节: %s",
        #     hex(header["obj_include_count"]),
        #     hex(header["obj_face_groups_count"]),
        #     hex(header["obj_vertex_count"]),
        #     hex(header["obj_vertex_byte"]),
        # )

        return header
    except Exception as e:
        log.debug(f"READ_HEAD: 读取网格头部失败: {e}")
        return None


def read_vertex(
    mmap_obj: mmap.mmap, obj_vertex_count: int, obj_vertex_byte: int
) -> Optional[TVertexData]:
    """读取顶点数据"""
    try:
        # 读取顶点数据
        obj_v_byte_data = mmap_obj.read(obj_vertex_byte)

        # 每个顶点数据块的大小
        obj_vertex_block_size = obj_vertex_byte // obj_vertex_count

        # 顶点数据返回值
        result: TVertexData = {
            "vertex": [],
            "normals": [],
            "uvs": [],
            "obj_vertex_block_size": obj_vertex_block_size,
        }

        # 读取顶点数据, 法线, UV (数量根据 obj_vertex_count 来确定)
        for i in range(obj_vertex_count):
            # 顶点数据块的偏移位置
            vertex_offset = obj_vertex_block_size * i
            if vertex_offset + obj_vertex_block_size > obj_vertex_byte:
                log.debug("READ_VERTEX: 顶点数据块超出范围")
                break

            # 读取顶点位置
            vx = struct.unpack_from("f", obj_v_byte_data, vertex_offset)[0]
            vy = struct.unpack_from("f", obj_v_byte_data, vertex_offset + 0x4)[0]
            vz = struct.unpack_from("f", obj_v_byte_data, vertex_offset + 0x8)[0]
            result["vertex"].append((vx, vy, vz))

            # 读取法线
            nx = struct.unpack_from("<e", obj_v_byte_data, vertex_offset + 0x0C)[0]
            ny = struct.unpack_from("<e", obj_v_byte_data, vertex_offset + 0x0E)[0]
            nz = struct.unpack_from("<e", obj_v_byte_data, vertex_offset + 0x10)[0]
            result["normals"].append((nx, ny, nz))

            # 读取UV
            uv_offset = vertex_offset + obj_vertex_block_size - OBJ_VERTEX_UV_OFFSET
            u = struct.unpack_from("<e", obj_v_byte_data, uv_offset)[0]
            v = struct.unpack_from("<e", obj_v_byte_data, uv_offset + 0x2)[0]
            result["uvs"].append((u, 1 - v))

        return result
    except Exception as e:
        log.debug(f"READ_VERTEX: 读取顶点数据失败: {e}")
        return None


def read_faces(mmap_obj: mmap.mmap) -> Optional[List[Tuple[int, int, int]]]:
    """读取面数据"""
    try:
        # 获取面数据字节大小
        faces_size_buffer = mmap_obj.read(4)
        faces_byte_size = struct.unpack("<I", faces_size_buffer)[0]

        # 获取面字节数据
        faces_byte_data = mmap_obj.read(faces_byte_size)

        # 读取到的面数据
        faces = []

        # 读取面数据
        for i in range(0, faces_byte_size, 12):
            f0 = struct.unpack_from("I", faces_byte_data, i)[0]
            f1 = struct.unpack_from("I", faces_byte_data, i + 0x4)[0]
            f2 = struct.unpack_from("I", faces_byte_data, i + 0x8)[0]
            faces.append((f0, f1, f2))

        return faces
    except Exception as e:
        log.debug(f"READ_FACE: 读取面数据失败: {e}")
        return None


def read_colormap(
    mmap_obj: mmap.mmap, color_start_offset: int, color_end_offset: int
) -> TColorMapData:
    """读取贴图信息"""
    try:
        # 读取贴图数据
        colors_data = mmap_obj[color_start_offset:color_end_offset]
        log.debug(f"READ_COLOR: 贴图数据大小: {hex(len(colors_data))}")
        # 查找是否包含贴图信息
        colormap_pos = colors_data.find(b"ColorMap")
        if colormap_pos != -1:
            # 贴图路径长度
            path_length = struct.unpack_from("<B", colors_data, colormap_pos + 0x8)[0]

            # 贴图路径
            path = colors_data[colormap_pos + 0xC : colormap_pos + 0xC + path_length]

            path_str = path.decode("utf-8", errors="replace")

            # 贴图名称
            color_map_name = extract_name_from_path(path_str)
            log.debug(f"READ_COLOR: 贴图路径: {path_str} , 贴图名称: {color_map_name}")

            # 读取贴图数据
            return TColorMapData(path=path_str, name=color_map_name)
        else:
            log.debug("READ_COLOR: !!! 此物体不包含贴图信息 !!!")
            return TColorMapData()

    except Exception as e:
        log.debug(f"READ_COLOR: 解析贴图数据失败: {e}")
        return TColorMapData()


def find_next_head(mmap_obj: mmap.mmap, block_size: int) -> bool:
    """逐字节寻找下个物体头部"""
    global MESH_FRIST_OBJECT_COUNT

    log.debug(
        f"NEXT_HEAD: 查找起点: {hex(mmap_obj.tell())}, 块大小: {hex(block_size)}, 总网物体数: {hex(MESH_FRIST_OBJECT_COUNT)}"
    )

    # 文件大小
    mmap_obj_size = mmap_obj.size()
    # 当前位置
    current_pos = mmap_obj.tell()

    try:
        global OBJ_HEAD
        # 逐字节寻找下个物体头部
        while current_pos + OBJ_HEAD["size"] < mmap_obj_size:
            # 更新当前位置
            current_pos = mmap_obj.tell()
            # log.debug(f"current_pos: {hex(current_pos)}")

            # 读取头部数据
            header: TObjHeader = read_obj_header(mmap_obj)

            # 验证初次返回的头部是否有效
            if header is None:
                # 无效数据，继续寻找
                mmap_obj.seek(current_pos + 1)
                continue
            else:
                # log.debug(f"NEXT_HEAD: 包含物体: {hex(obj_inc)}")
                # 增强头部校验
                if (
                    header["obj_vertex_count"] < header["obj_vertex_byte"]
                    and header["obj_vertex_count"] * block_size
                    == header["obj_vertex_byte"]
                    and header["obj_vertex_byte"] + current_pos < mmap_obj_size
                    and (
                        header["obj_include_count"] <= MESH_FRIST_OBJECT_COUNT
                        and header["obj_include_count"] < 8
                        # 防止读取到无效数据, 一般是 0 , 1, 2
                    )
                ):
                    # 回退位置
                    mmap_obj.seek(current_pos)
                    log.debug(
                        f"NEXT_HEAD: mmap_obj.tell(): {hex(mmap_obj.tell())}, current_pos: {hex(current_pos)}"
                    )

                    return True
                else:  # 不是正常的头部数据，继续寻找
                    mmap_obj.seek(current_pos + 1)
                    continue

        log.debug(f"NEXT_HEAD: 未能逐字节寻找到下个物体头部地址!")
        return False
    except Exception as e:
        log.debug(f"NEXT_HEAD: 逐字节寻找下个物体头部失败: {e}")
        return False


def process_single_obj(mmap_obj: mmap.mmap) -> Optional[TMeshData]:
    """处理单个物体数据"""

    # 1. 读取物体头部信息
    header_data: Optional[TObjHeader] = read_obj_header(mmap_obj)

    # 检查是否读取到有效数据
    if header_data is None:
        log.debug("读取物体头部失败")
        return None

    # 2. 读取顶点数据
    vertex_data: Optional[TVertexData] = read_vertex(
        mmap_obj, header_data["obj_vertex_count"], header_data["obj_vertex_byte"]
    )

    # 验证返回的数据是否有效
    if vertex_data is None:
        log.debug("读取顶点数据失败")
        return None

    # 3. 读取面数据
    faces_data = read_faces(mmap_obj)

    # 验证返回的数据是否有效
    if faces_data is None:
        log.debug("读取面数据失败")
        return None

    # 4. 查找下个物体头部位置
    # 贴图数据开始位置
    color_start_offset = mmap_obj.tell()

    # 查找下一个物体头部位置
    next_obj_start = find_next_head(mmap_obj, vertex_data["obj_vertex_block_size"])

    # 贴图数据结束位置
    color_end_offset = mmap_obj.tell()

    # 5. 读取贴图数据
    # 贴图数据
    colormap_res = TColorMapData()

    if next_obj_start is True:
        # 读取贴图数据
        colormap_res = read_colormap(mmap_obj, color_start_offset, color_end_offset)
    else:
        log.debug(f"未找到下一个物体头部地址, 处理最后一个网格")
        # 读取贴图数据
        colormap_res = read_colormap(mmap_obj, color_start_offset, color_end_offset)

    # 6. 构建物体数据
    mesh_data = TMeshData(
        mesh_obj_number=header_data["obj_include_count"],
        obj_vertex_count=header_data["obj_vertex_count"],
        vertex_data=vertex_data["vertex"],
        faces_data=faces_data,
        uvs=vertex_data["uvs"],
        normals=vertex_data["normals"],
        colormap=colormap_res,
    )

    return mesh_data


def process_meshe(mmap_obj: mmap.mmap) -> List[TMeshData]:
    """处理网格数据"""

    # 读取Mesh头部的MinPos MaxPos
    pos_read_ok = read_minpos_maxpos(mmap_obj)

    # 校验是否读取到有效数据
    if pos_read_ok is False:
        log.debug("读取MinPos MaxPos失败,或非Map Mesh文件!!!")
        return []

    # 所有物体数据列表
    mesh_objects = []
    global MESH_FRIST_OBJECT_COUNT, MESH_OBJECT_READED

    try:
        while True:
            log.debug(
                f"已处理{hex(MESH_OBJECT_READED)} ! 共 {hex(MESH_FRIST_OBJECT_COUNT)}"
            )

            # 读取并处理单个物体
            mesh_data: Optional[TMeshData] = process_single_obj(mmap_obj)

            # 检查是否读取到有效数据
            if mesh_data is None:
                log.debug("读取物体数据失败")
                break

            # 将读取到的物体数据添加到列表中
            mesh_objects.append(mesh_data)
            MESH_OBJECT_READED += 1

        log.debug(f"共处理 {len(mesh_objects)} 个网格对象")
        return mesh_objects
    except Exception as e:
        log.debug(f"处理网格数据失败: {e}")
        return mesh_objects


def read_mesh_func(filepath: str) -> List[TMeshData]:
    """读取并处理网格文件"""
    try:
        # 重置全局变量
        rest_global_val()

        # 读取文件
        with open(filepath, "rb") as f:
            # 使用内存映射的方式读取文件数据
            with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mmap_obj:
                # 处理网格数据
                res: List[TMeshData] = process_meshe(mmap_obj)

                return res
    except Exception as e:
        log.debug(f"文件读取失败: {e}")
        # 重置全局变量
        rest_global_val()
        return []
