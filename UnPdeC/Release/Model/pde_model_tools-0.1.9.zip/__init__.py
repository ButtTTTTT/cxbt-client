# __init__.py
import bpy
from bpy.props import StringProperty, PointerProperty
from bpy.types import AddonPreferences, PropertyGroup
from .log import get_module_logger

log = get_module_logger("CORE")

# 主包名
MAIN_PACKAGE = __package__

# 导出主包名常量，使子模块可获取到主包名
__all__ = ("MAIN_PACKAGE",)


class PMT_SceneProperties(PropertyGroup):
    """场景级别的属性，用于存储用户在 UI 面板中的选择"""
    
    # 骨架导入的目标物体
    skel_target_object: PointerProperty(
        name="Target object",
        type=bpy.types.Object,
        description="选择要将骨架添加到的目标物体，留空则创建新物体 \nSelect the target object to add the skeleton to, or leave blank to create a new object.",
    )  # type: ignore


# 导入子模块
from .ui import PMT_OT_ResourceDir, PMT_OT_ClearResourceDir, PMT_OT_CleanupUnusedData, PMT_PT_UiPanel
from .mesh_any.operator import PMT_OT_AnyMesh
from .skel.operator import PMT_OT_Skel
from .anim.operator import PMT_OT_Anim


# 插件的偏好设置
class PMTAddonPreferences(AddonPreferences):
    bl_idname = __package__

    dir_path: StringProperty(
        name="资源根目录",
        subtype="DIR_PATH",
        default="",
        description="可以根据根目录来自动加载贴图",
    )  # type: ignore


# 类列表
classes = (
    PMTAddonPreferences,
    PMT_SceneProperties,
    PMT_OT_ResourceDir,
    PMT_OT_ClearResourceDir,
    PMT_OT_CleanupUnusedData,
    PMT_PT_UiPanel,
    PMT_OT_AnyMesh,
    PMT_OT_Anim,
    PMT_OT_Skel,
)


def register():
    # 注册类
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # 注册场景属性
    bpy.types.Scene.pmt_props = PointerProperty(type=PMT_SceneProperties)
    log.info("插件已启用")

def unregister():
    # 注销场景属性
    del bpy.types.Scene.pmt_props
    
    # 注销类
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    log.info("插件已注销")
