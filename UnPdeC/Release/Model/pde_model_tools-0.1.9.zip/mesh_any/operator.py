import bpy
import os
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, CollectionProperty, BoolProperty
from typing import Set, List, Tuple

from .. import MAIN_PACKAGE
from ..log import get_module_logger
from .parser import MeshParser
from .common import create_mesh_object_from_data

log = get_module_logger("MESH")



class PMT_OT_AnyMesh(bpy.types.Operator, ImportHelper):
    """通用网格导入 \nGeneral Mesh Import"""

    bl_idname = "pmt.any_mesh"
    bl_label = "Any Meshs"
    bl_options = {"REGISTER", "UNDO"}

    # 文件选择
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement, options={"HIDDEN"}
    )  # type: ignore
    directory: StringProperty(subtype="DIR_PATH")  # type: ignore
    filter_glob: StringProperty(default="*.mesh", options={"HIDDEN"})  # type: ignore
    
    # 后处理选项
    convert_to_quads: BoolProperty(
        name="三角面转四边面 (ALT+J)",
        description="将导入的网格中的三角面转换为四边面",
        default=False
    )  # type: ignore
    
    merge_by_distance: BoolProperty(
        name="⚠按距离合并顶点 (M)",
        description="按指定距离合并相邻的顶点\n\n⚠\n但是火箭兵的鼓在合并后会少一个鼓棰顶点组！\n所以建议手动合并！！！",
        default=False
    )  # type: ignore
    
    merge_distance: bpy.props.FloatProperty(
        name="合并距离阈值",
        description="顶点合并的距离阈值（单位：米）",
        default=0.0001,
        min=0.00001,
        max=1.0,
        step=0.00001,
        precision=5
    )  # type: ignore

    # 绘制文件选择界面的自定义选项
    def draw(self, context):
        """绘制文件选择界面的自定义选项"""
        layout = self.layout
        
        # 添加分隔线
        layout.separator()
        
        # 添加后处理选项
        box = layout.box()
        box.label(text="后处理选项:", icon='MODIFIER')
        
        col = box.column()
        col.prop(self, "convert_to_quads")
        
        col.prop(self, "merge_by_distance")
        if self.merge_by_distance:
            col.prop(self, "merge_distance")

    def execute(self, context):
        """执行导入操作"""

        # 成功导入数量
        imported_total = 0
        # 失败导入数量
        import_errors = []
        
        # 存储目录名 -> 父物体的映射
        # 用于将同一目录下的 mesh 放到同一个父物体下
        dir_to_parent: dict = {}

        # 检查文件是否存在
        if not self.files:
            self.report({"ERROR"}, "未选择任何文件")
            return {"CANCELLED"}

        # 遍历所有文件
        for file_elem in self.files:
            # 获取文件路径
            filepath = os.path.join(self.directory, file_elem.name)
            if not os.path.exists(filepath):
                import_errors += 1
                log.warning(f"文件不存在: {file_elem.name}")
                continue

            try:
                # 导入网格文件
                result, imported_objs = import_mesh(self, context, filepath, self.convert_to_quads, self.merge_by_distance, self.merge_distance)
                if result == {"FINISHED"}:
                    imported_total += 1
                    
                    # 获取 mesh 文件所在的目录名作为父物体名称
                    mesh_dir = os.path.basename(self.directory.rstrip(os.sep))
                    
                    # 检查是否已有该目录对应的父物体
                    if mesh_dir not in dir_to_parent:
                        # 检查场景中是否已有同名物体
                        parent_obj = context.scene.objects.get(mesh_dir)
                        if not parent_obj:
                            # 创建新的空物体作为父级
                            parent_obj = bpy.data.objects.new(mesh_dir, None)
                            parent_obj.empty_display_type = 'SPHERE'
                            parent_obj.empty_display_size = 0.1
                            context.collection.objects.link(parent_obj)
                            log.info(f"创建父物体: {mesh_dir}")
                        dir_to_parent[mesh_dir] = parent_obj
                    
                    # 将导入的 mesh 放到父物体下
                    parent_obj = dir_to_parent[mesh_dir]
                    for obj in imported_objs:
                        if obj and obj.parent is None:
                            obj.parent = parent_obj
                            log.debug(f"将 {obj.name} 添加到 {parent_obj.name} 下")
                    
            except Exception as e:
                log.error(f"导入失败 {file_elem.name}: {e}", exc_info=True)
                import_errors += 1
                log.warning(f"{file_elem.name}: {str(e)}")

        # 将第一个父物体设为活动物体
        if dir_to_parent:
            first_parent = list(dir_to_parent.values())[0]
            bpy.ops.object.select_all(action='DESELECT')
            first_parent.select_set(True)
            context.view_layer.objects.active = first_parent
        
        # 同时设置场景属性中的目标物体（方便后续导入骨架）
        if len(dir_to_parent) == 1:
            first_parent = list(dir_to_parent.values())[0]
            if hasattr(context.scene, 'pmt_props'):
                context.scene.pmt_props.skel_target_object = first_parent
                log.info(f"已设置骨架目标物体: {first_parent.name}")

        if import_errors:
            self.report({"WARNING"},f"导入失败数量: {import_errors}")
            return {"CANCELLED"}
        
        return {"FINISHED"}


def post_process_mesh_objects(context: bpy.types.Context, imported_objects: List[bpy.types.Object], convert_to_quads: bool = False, merge_by_distance: bool = False, merge_distance: float = 0.0001) -> None:
    """
    导入后处理网格对象
    
    Args:
        context: Blender上下文对象
        imported_objects: 刚刚导入的对象列表
        convert_to_quads: 是否将三角面转换为四边面
        merge_by_distance: 是否按距离合并顶点
        merge_distance: 合并距离阈值
    """
    if not convert_to_quads and not merge_by_distance:
        return
    
    # 使用导入的对象而不是选中的对象
    mesh_objects = [obj for obj in imported_objects if obj and obj.type == 'MESH']
    
    if not mesh_objects:
        log.debug("没有找到需要处理的网格对象")
        return
    
    log.info(f"开始后处理 {len(mesh_objects)} 个网格对象...")
    
    # 取消所有选择
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in mesh_objects:
        # 选中当前对象
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        
        # 进入编辑模式
        bpy.ops.object.mode_set(mode='EDIT')
        
        # 确保所有元素都被选中
        bpy.ops.mesh.select_all(action='SELECT')
        
        # 转换三角面到四边面 (ALT+J)
        if convert_to_quads:
            face_count_before = len(obj.data.polygons)
            bpy.ops.mesh.tris_convert_to_quads()
            face_count_after = len(obj.data.polygons)
            log.debug(f"已将对象 {obj.name} 的三角面转换为四边面: {face_count_before} -> {face_count_after} 个面")
        
        # 按距离合并顶点 (M)
        if merge_by_distance:
            vertex_count_before = len(obj.data.vertices)
            bpy.ops.mesh.remove_doubles(threshold=merge_distance)
            vertex_count_after = len(obj.data.vertices)
            removed_count = vertex_count_before - vertex_count_after
            log.debug(f"已按距离 {merge_distance} 合并对象 {obj.name} 的顶点: {vertex_count_before} -> {vertex_count_after} (移除 {removed_count} 个)")
        
        # 返回对象模式
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # 取消选择当前对象
        obj.select_set(False)
    
    # 重新选择所有导入的对象
    for obj in imported_objects:
        if obj:
            obj.select_set(True)
    
    log.info(f"后处理完成 - 处理了 {len(mesh_objects)} 个网格对象")


def import_mesh(self, context: bpy.types.Context, filepath: str, convert_to_quads: bool = False, merge_by_distance: bool = False, merge_distance: float = 0.0001) -> Tuple[Set[str], List[bpy.types.Object]]:
    """
    导入网格文件的通用方法
    
    遵循Blender 4.5的导入操作最佳实践，处理多种网格文件格式的导入流程。
    包括文件解析、网格创建、材质设置和边界框生成等完整流程。
    
    Args:
        self: 操作器实例
        context: Blender上下文对象
        filepath: 要导入的网格文件路径
    
    Returns:
        操作结果集，包含导入状态信息
    
    Raises:
        FileNotFoundError: 当指定的文件不存在时
        RuntimeError: 当文件解析或网格创建失败时
    """
    try:
        # 获取资源路径
        res_dir_path = context.preferences.addons[MAIN_PACKAGE].preferences.dir_path

        # 解析网格文件
        parser = MeshParser()
        mesh_objects = parser.parse_file(filepath)

        if not mesh_objects:
            log.debug(f"未能读取到有效的网格数据,Mesh文件可能损坏!")
            return {"CANCELLED"}, []

        base_name = os.path.splitext(os.path.basename(filepath))[0]
        processed_materials = set()
        imported_count = 0
        imported_objects = []  # 收集导入的对象

        # 根据网格类型进行特定处理
        mesh_type = parser.MESH_GVAL["type"]
        log.info(f"处理 {mesh_type} 类型的网格文件: {base_name}")

        # 处理每个网格对象
        for idx, mesh_data in enumerate(mesh_objects, 1):
            # 获取物体名称（仅CW类型有）
            obj_namess = getattr(parser, 'obj_names', []) if mesh_type == "CW" else None
            obj = create_mesh_object_from_data(
                context,
                mesh_data,
                base_name,
                idx,
                processed_materials,
                res_dir_path,
                mesh_type,
                obj_namess,
            )
            if obj:
                imported_objects.append(obj)  # 添加到导入对象列表
                imported_count += 1

        # 只打印边界框信息，不创建实际对象
        bbox_count = 0
        if hasattr(parser, 'bbox_list') and parser.bbox_list:
            # CW类型：打印每个物体的边界框信息
            for i, bbox_data in enumerate(parser.bbox_list):
                log.info(f"边界框 {i+1}: {bbox_data['name']} - Min{bbox_data['min_position']}, Max{bbox_data['max_position']}")
                bbox_count += 1
        elif parser.min_position is not None and parser.max_position is not None:
            # Map/Prop类型：打印单个边界框信息
            log.info(f"边界框: Min{parser.min_position}, Max{parser.max_position}")
            bbox_count = 1

        # 执行后处理操作
        if convert_to_quads or merge_by_distance:
            post_process_mesh_objects(context, imported_objects, convert_to_quads, merge_by_distance, merge_distance)
            
            # 更新报告消息
            process_info = []
            if convert_to_quads:
                process_info.append("三角面转四边面")
            if merge_by_distance:
                process_info.append(f"按距离合并({merge_distance})")
            
            process_str = ", ".join(process_info)
        else:
            process_str = "未执行后处理"
        
        report_msg = f"导入完成: \n共 {parser.MESH_INCLUDE_OBJECT} 个物体, 导入{imported_count} 个物体，类型: {mesh_type}, 版本: {parser.MESH_GVAL['version']}"
        if bbox_count > 0:
            report_msg += f", 共 {bbox_count} 个边界盒"
        report_msg += f", \n后处理: {process_str}"
        if not convert_to_quads and not merge_by_distance:
            report_msg += f", \n优化建议: \n进入编辑模式: \n1: ALT+J -> 三角面 转 四边面。\n2: M -> 按距离 合并！(这样才能绑定骨骼)"
        
        log.info(report_msg)
        self.report({"INFO"}, report_msg)
        return {"FINISHED"}, imported_objects
    except Exception as e:
        log.error(f"导入失败: {e}", exc_info=True)
        self.report({"ERROR"}, f"严重错误: {str(e)}")
        return {"CANCELLED"}, []
