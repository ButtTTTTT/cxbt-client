"""
网格文件解析器模块

提供多种网格文件格式的解析功能，支持Prop、Map、Character/Weapon等类型。
遵循Blender 4.5的Python API最佳实践，确保代码的可靠性和可维护性。
"""

import mmap
import struct
import os
from typing import List, Tuple, Optional, Dict, Any

from ..log import get_module_logger

log = get_module_logger("MESH")


class MeshParser:
    """
    网格文件解析器类
    
    封装多种网格文件格式的解析逻辑，支持版本检测、数据提取和错误处理。
    """

    def reset_parser_state(self) -> None:
        """
        重置解析器状态到初始值
        
        在解析新文件之前调用，确保解析器状态干净。
        """
        # 常量定义
        self.FILE_TYPE_8_BYTE = 0x8  # 8字节文件类型标识
        self.MINPOS_MAXPOS_SIZE = 0x18  # MinPos/MaxPos数据块大小（24字节）
        
        # 解析状态变量
        self.mesh_object_count = 0  # 网格文件中包含的物体总数
        self.objects_processed_count = 0  # 已成功处理的物体数量
        self.MESH_INCLUDE_OBJECT = 0  # 网格文件中包含的物体总数（兼容旧代码）
        self.MESH_OBJECT_READED = 0  # 已成功处理的物体数量（兼容旧代码）
        
        # 边界框数据
        self.min_position = None  # 最小边界坐标
        self.max_position = None  # 最大边界坐标
        self.bounding_box_list = []  # 所有物体的边界框数据列表
        
        # 物体名称数据（用于CW类型顶点组命名）
        self.obj_names = []  # 从文件中读取的物体名称列表
        
        # 网格类型配置字典
        self.MESH_TYPE_CONFIGURATION = {
            # 未设置状态
            "Unset": {
                "type": "Unset",  # 网格类型标识
                "version": "",  # 版本标识
                "header_size": 0x0,  # 物体头部大小
                "vertex_bytes_offset": 0x0,  # 顶点数据字节偏移
                "bone_indices_offset": 0x0,  # 骨骼索引偏移
                "uv_offset": 0x0,  # UV数据偏移
            },
            # Prop 物品 类型配置
            "Prop_V1": {
                "type": "Prop",
                "version": "V1",
                "header_size": 0x1D,
                "vertex_bytes_offset": 0x19,
                "uv_offset": 0x10,
            },
            "Prop_V2": {
                "type": "Prop",
                "version": "V2",
                "header_size": 0x21,
                "vertex_bytes_offset": 0x1D,
                "uv_offset": 0x10,
            },
            # Map 地图 类型配置
            "Map_V1": {
                "type": "Map",
                "version": "V1",
                "header_size": 0x1D,
                "vertex_bytes_offset": 0x19,
                "uv_offset": 0x10,
            },
            "Map_V2": {
                "type": "Map",
                "version": "V2",
                "header_size": 0x21,
                "vertex_bytes_offset": 0x1D,
                "uv_offset": 0x10,
            },
            # Character/Weapon 人物与武器 类型配置
            "CW_V1": {
                "type": "CW",
                "version": "V1",
                "header_size": 0x1D,
                "vertex_bytes_offset": 0x19,
                "bone_indices_offset": 0x24,
                "uv_offset": 0x8,
            },
            "CW_V2": {
                "type": "CW",
                "version": "V2",
                "header_size": 0x21,
                "vertex_bytes_offset": 0x1D,
                "uv_offset": 0x8,
            },
        }
        
        # 当前网格配置（初始为未设置）
        self.current_mesh_config = self.MESH_TYPE_CONFIGURATION["Unset"]
        self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["Unset"]  # 初始化MESH_GVAL

    def extract_name_from_path(self, path: str) -> str:
        """从路径中提取文件名（不包含扩展名）"""
        try:
            return os.path.splitext(os.path.basename(path))[0]
        except Exception:
            return ""

    def read_minpos_maxpos(self, mmap_obj: mmap.mmap) -> bool:
        """读取MinPos MaxPos"""
        try:
            if mmap_obj.size() < self.MINPOS_MAXPOS_SIZE:
                log.debug("MinPos MaxPos数据不足")
                return False

            pos_data = mmap_obj.read(self.FILE_TYPE_8_BYTE + self.MINPOS_MAXPOS_SIZE)
            min_x, min_y, min_z, max_x, max_y, max_z = struct.unpack(
                "<ffffff", pos_data
            )
            log.debug(f"Min Pos: x: {min_x} y: {min_y} z: {min_z}")
            log.debug(f"Max Pos: x: {max_x} y: {max_y} z: {max_z}")

            # 保存MinPos MaxPos数据
            self.min_position = (min_x, min_y, min_z)
            self.max_position = (max_x, max_y, max_z)

            return True
        except Exception as e:
            log.error(f"读取MinPos MaxPos失败,可能遇到了奇怪的文件: {e}")
            return True

    def check_mesh_type_and_version(self, mmap_obj: mmap.mmap):
        """检查网格类型和版本"""
        log.debug("检查网格类型和版本")

        # AS/FC/RF Mesh前8字节
        # 静态mesh - 物品, 地图, 无动画
        # 00010000 01000000 -> 紧跟着的是MinPos/MaxPos
        
        # 动态mesh - 人物, 武器, 有动画
        # 00010000 02000000 -> 紧跟着的是骨骼索引列表

        # 获取前4字节 - 类型
        mesh_type = mmap_obj[0:4]
        # 获取后4字节 - 版本
        mesh_version = mmap_obj[4:8]
        log.debug(f"文件类型: {mesh_type.hex()}")
        log.debug(f"文件版本: {mesh_version.hex()}")

        # 检查是否是mesh文件
        if mesh_type != b"\x00\x01\x00\x00":
            log.warning("文件类型不是Mesh!")
            return None

        # 检查类型
        meshhead:bytes
        if mesh_version == b"\x01\x00\x00\x00":
            log.debug("文件类型: 静态Mesh")
            # 静态Mesh文件头部数据 - [跳过 前8字节+MinPos/MaxPos,到达Mesh头部数据]
            meshhead = mmap_obj[self.FILE_TYPE_8_BYTE + self.MINPOS_MAXPOS_SIZE : self.FILE_TYPE_8_BYTE + self.MINPOS_MAXPOS_SIZE + 0x21]
        elif mesh_version == b"\x02\x00\x00\x00":
            log.debug("文件类型: 动态Mesh")
            # 是 Character / Weapon 文件
            # 使用正确的配置字典而不是直接修改type字段
            self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["CW_V1"]  # 默认使用V1版本
            log.debug("判定为 Character / Weapon")

            return self.MESH_GVAL["type"]
        else:
            log.debug("!!!!!! 文件类型: 未知")

        # 尝试读取关键字段
        try:
            # Mesh中包含物体数量
            mesh_obj_count = struct.unpack_from("<I", meshhead, 0x0)[0]
            # Mesh中第一个物体包含面数量
            obj_face_count = struct.unpack_from("<I", meshhead, 0x4)[0]
            # Mesh中第一个物体包含顶点数量
            obj_vertex_count = struct.unpack_from("<I", meshhead, 0x8)[0]
            # Mesh中第一个物体顶点数据大小 - V1版本
            obj_vbyte_v1 = struct.unpack_from("<I", meshhead, 0x19)[0]
            # Mesh中第一个物体顶点数据大小 - V2版本
            obj_vbyte_v2 = struct.unpack_from("<I", meshhead, 0x1D)[0]

            # 基本验证
            if mesh_obj_count <= 0 or obj_face_count <= 0 or obj_vertex_count <= 0:
                return

            # 判断Mesh版本
            # 类型为 旧版本(V1) Map 或 Prop 文件
            if obj_vbyte_v1 // obj_vertex_count == 0x34:
                if mesh_obj_count > 1:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["Map_V1"]
                    log.debug("判定为 Map V1")
                elif mesh_obj_count == 1:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["Prop_V1"]
                    log.debug("判定为 Prop V1")
            # 类型为 新版本(V2) Map 或 Prop 文件
            elif obj_vbyte_v2 // obj_vertex_count == 0x34:
                if mesh_obj_count > 1:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["Map_V2"]
                    log.debug("判定为 Map V2")
                elif mesh_obj_count == 1:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["Prop_V2"]
                    log.debug("判定为 Prop V2")
            # # 可能是角色/武器类型
            # else:
            #     # 可能是 Character / Weapon 文件
            #     # 使用正确的配置字典而不是直接修改type字段
            #     self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["CW_V1"]  # 默认使用V1版本
            #     log.debug("判定为 Character / Weapon")

            return self.MESH_GVAL["type"]
        except Exception as e:
            log.debug(f"头部数据解析失败: {e}")
            return None

    def read_obj_header(self, mmap_obj: mmap.mmap):
        """读取物体头部信息,并在首次判断mesh类型"""
        try:
            # 当前位置
            # current_pos = mmap_obj.tell()
            # log.debug(f"current_pos: {hex(current_pos)}")

            # 读取头部数据
            if mmap_obj.tell() + self.MESH_GVAL["header_size"] > mmap_obj.size():
                return None

            # 0x1D Head
            # 15000000 241E0000 483C0000 00000000 02000000 02000000 01A03E0C 00
            # 0x21 Head
            # 70010000 A0010000 40030000 00000000 00000000 00000000 00000000 0000A900 00
            header_data = mmap_obj.read(self.MESH_GVAL["header_size"])
            header = {
                "mesh_obj_count": struct.unpack_from("<I", header_data, 0x0)[0],
                "obj_face_count": struct.unpack_from("<I", header_data, 0x4)[0],
                "obj_vertex_count": struct.unpack_from("<I", header_data, 0x8)[0],
                "obj_vertex_byte": struct.unpack_from(
                    "<I", header_data, self.MESH_GVAL["vertex_bytes_offset"]
                )[0],
            }

            # 读取头部数据后的位置
            readed_current_pos = mmap_obj.tell()
            # log.debug(f"readed_current_pos: {hex(readed_current_pos)}")

            # 获取此物体实际面数据占用字节
            try:
                obj_face_size = struct.unpack_from("<I", mmap_obj, readed_current_pos + header["obj_vertex_byte"])[0]
                # log.debug(f"读取完面占用字节后的位置: {hex(mmap_obj.tell())}")
            except Exception as e:
                # log.debug(f"读取面占用字节失败: {e}")
                return None

            # 首次更新总物体数
            if self.MESH_INCLUDE_OBJECT == 0:
                self.MESH_INCLUDE_OBJECT = header["mesh_obj_count"]
                self.mesh_object_count = header["mesh_obj_count"]  # 同步更新新属性

            # 验证头部数据
            if (
                # header["mesh_obj_count"] < 0
                header["obj_face_count"] <= 0
                or header["obj_vertex_count"] <= 0
                or header["obj_vertex_byte"] <= 0
                or header["mesh_obj_count"] > header["obj_vertex_byte"]
                or header["obj_face_count"] > header["obj_vertex_count"]
                or header["obj_face_count"] > header["obj_vertex_byte"]
                or header["obj_vertex_count"] > header["obj_vertex_byte"]
                or obj_face_size / 0xc != header["obj_face_count"]
                # 判断实际面数据占用大小是否与头部数据一致！
            ):
                # log.debug("物体头部数据错误")
                return None

            return header
        except Exception as e:
            log.error(f"读取网格头部失败: {e}")
            return None

    def read_vertex(
        self, mmap_obj: mmap.mmap, obj_vertex_count: int, obj_vertex_byte: int
    ):
        """读取顶点数据"""
        try:
            # 读取顶点数据
            obj_v_byte_data = mmap_obj.read(obj_vertex_byte)
            # 每个顶点数据块的大小
            obj_vertex_block_size = obj_vertex_byte // obj_vertex_count

            # 顶点数据返回值
            result = {
                "vertex": [],
                "normals": [],
                "tangents": [],
                "binormals": [],
                "bone_indices": [],
                "bone_weights": [],
                "uvs": [],
                "obj_vertex_block_size": obj_vertex_block_size,
            }

            # 读取顶点数据, 法线, UV (数量根据 obj_vertex_count 来确定)
            for i in range(obj_vertex_count):
                # 顶点数据块的偏移位置
                v_offset = obj_vertex_block_size * i
                if v_offset + obj_vertex_block_size > obj_vertex_byte:
                    log.debug("READ_VERTEX: 顶点数据块超出范围")
                    break

                # 顶点
                vx, vy, vz = struct.unpack_from("fff", obj_v_byte_data, v_offset)
                result["vertex"].append((vx, vy, vz))

                # 法线
                nx, ny, nz = struct.unpack_from(
                    "<eee", obj_v_byte_data, v_offset + 0x0C
                )
                result["normals"].append((nx, ny, nz))

                # 根据网格类型添加额外数据
                if self.MESH_GVAL["type"] == "CW":
                    # CW类型：包含切线、副法线、骨骼数据
                    # 切线
                    tx, ty, tz = struct.unpack_from(
                        "<eee", obj_v_byte_data, v_offset + 0x14
                    )
                    result["tangents"].append((tx, ty, tz))

                    # 副法线
                    bx, by, bz = struct.unpack_from(
                        "<eee", obj_v_byte_data, v_offset + 0x1C
                    )
                    result["binormals"].append((bx, by, bz))

                    # 骨骼索引 (0x24-0x27)
                    b0, b1, b2, b3 = struct.unpack_from("<BBBB", obj_v_byte_data, v_offset + 0x24)
                    result["bone_indices"].append((b0, b1, b2, b3))

                    # 骨骼权重 (0x28-0x37)
                    w0, w1, w2, w3 = struct.unpack_from("<ffff", obj_v_byte_data, v_offset + 0x28)
                    result["bone_weights"].append((w0, w1, w2, w3))

                # UV
                uv_offset = (
                    v_offset + obj_vertex_block_size - self.MESH_GVAL["uv_offset"]
                )
                u, v = struct.unpack_from("<ee", obj_v_byte_data, uv_offset)
                result["uvs"].append((u, 1 - v))

            return result
        except Exception as e:
            log.error(f"读取顶点数据失败: {e}")
            return None

    def read_faces(self, mmap_obj: mmap.mmap):
        """读取面数据"""
        try:
            # 获取面数据字节大小
            faces_byte_size = struct.unpack("<I", mmap_obj.read(4))[0]
            faces_byte_data = mmap_obj.read(faces_byte_size)
            # 面数据返回值
            faces = []

            # 读取面数据(12 == 3 * 4 == 3个顶点 * 4字节)
            for i in range(0, faces_byte_size, 12):
                f0, f1, f2 = struct.unpack_from("III", faces_byte_data, i)
                faces.append((f0, f1, f2))

            return faces
        except Exception as e:
            log.error(f"读取面数据失败: {e}")
            return None

    def find_next_head(self, mmap_obj: mmap.mmap, block_size: int) -> bool:
        """逐字节寻找下个物体头部"""

        log.debug(
            f"查找下一个头部: 当前位置: {hex(mmap_obj.tell())}, 块大小: {hex(block_size)}, 总物体数: {hex(self.MESH_INCLUDE_OBJECT)}"
        )

        # 文件大小
        mmap_obj_size = mmap_obj.size()
        # 当前位置
        current_pos = mmap_obj.tell()

        try:
            # 逐字节寻找下个物体头部
            while current_pos + self.MESH_GVAL["header_size"] < mmap_obj_size:
                # 更新当前位置
                current_pos = mmap_obj.tell()

                # 读取头部数据
                header = self.read_obj_header(mmap_obj)

                # 验证初次返回的头部是否有效
                if header is None:
                    # 无效数据，继续寻找
                    mmap_obj.seek(current_pos + 1)
                    continue
                else:
                    # 增强头部校验
                    if (
                        header["obj_vertex_count"] < header["obj_vertex_byte"]
                        and header["obj_vertex_count"] * block_size
                        == header["obj_vertex_byte"]
                        and header["obj_vertex_byte"] + current_pos < mmap_obj_size
                        and (
                            header["mesh_obj_count"] <= self.MESH_INCLUDE_OBJECT
                            and header["mesh_obj_count"] < 8
                            # 防止读取到无效数据, 一般是 0 , 1, 2
                        )
                    ):
                        # 回退位置
                        mmap_obj.seek(current_pos)
                        log.debug(f"找到下一个头部: 位置: {hex(mmap_obj.tell())}")

                        return True
                    else:  # 不是正常的头部数据，继续寻找
                        mmap_obj.seek(current_pos + 1)
                        continue

            log.debug(f"未能找到下一个物体头部地址")
            return False
        except Exception as e:
            log.error(f"寻找下一个物体头部失败: {e}")
            return False

    def read_texture_map(self, texture_data: bytes, map_type: str):
        """读取贴图信息"""
        try:
            # 定义可能的贴图标识符变体
            map_variants = [map_type]
            
            # 如果类型包含数字1，也尝试不带数字的变体
            if map_type.endswith("1"):
                map_variants.append(map_type[:-1])  # 去掉末尾的1
            # 如果类型不包含数字1，也尝试带数字1的变体
            elif not map_type.endswith("1"):
                map_variants.append(map_type + "1")

            # 尝试所有可能的标识符变体
            for map_variant in map_variants:
                map_identifier = map_variant.encode('utf-8')
                map_pos = texture_data.find(map_identifier)

                if map_pos != -1:
                    log.debug(f"找到{map_variant}标识: 偏移量: {hex(map_pos)}")

                    # 贴图路径长度(标识符长度 + 4字节长度字段)
                    path_length = struct.unpack_from("<B", texture_data, map_pos + len(map_identifier))[0]

                    # 贴图路径
                    path_start = map_pos + len(map_identifier) + 4  # 标识符长度 + 4字节长度字段
                    path = texture_data[path_start : path_start + path_length]

                    # 解码路径字符串
                    path_str = path.decode("utf-8", errors="replace")

                    # 提取贴图名称
                    texture_name = self.extract_name_from_path(path_str)
                    log.debug(f"{map_variant}路径: {path_str}, 贴图名称: {texture_name}")

                    return {"path": path_str, "name": texture_name, "type": map_variant}

            log.debug(f"此物体不包含{map_type}信息（尝试了变体: {', '.join(map_variants)}）")
            return {"path": "", "name": "", "type": ""}
        except Exception as e:
            log.error(f"解析{map_type}数据失败: {e}")
            return {"path": "", "name": "", "type": ""}

    def read_colormap(self, mmap_obj: mmap.mmap, color_start_offset: int, color_end_offset: int):
        """读取所有贴图信息（统一处理标识符变体）"""
        try:
            # 获取贴图数据范围
            texture_data = mmap_obj[color_start_offset:color_end_offset]
            
            # 读取ColorMap
            colormap = self.read_texture_map(texture_data, "ColorMap")
            
            # 读取SrMap（统一处理SrMap和SrMap1）
            srmap = self.read_texture_map(texture_data, "SrMap")
            
            # 读取DrMap（统一处理DrMap和DrMap1）
            drmap = self.read_texture_map(texture_data, "DrMap")
            
            return {
                "colormap": colormap,
                "srmap": srmap,
                "drmap": drmap
            }
        except Exception as e:
            log.error(f"解析贴图数据失败: {e}")
            return {
                "colormap": {"path": "", "name": "", "type": ""},
                "srmap": {"path": "", "name": "", "type": ""},
                "drmap": {"path": "", "name": "", "type": ""}
            }

    def process_single_obj(self, mmap_obj: mmap.mmap):
        """处理单个物体数据"""

        # 1. 读取物体头部信息
        header = self.read_obj_header(mmap_obj)
        if not header:
            log.debug("读取物体头部失败")
            return None

        # 2. 读取顶点数据
        vertex_data = self.read_vertex(
            mmap_obj, header["obj_vertex_count"], header["obj_vertex_byte"]
        )
        if not vertex_data:
            log.debug("读取顶点数据失败")
            return None

        # 3. 读取面数据
        faces_data = self.read_faces(mmap_obj)
        if not faces_data:
            log.debug("读取面数据失败")
            return None

        # 4. 读取下一个物体头部位置 与 贴图数据起始位置
        # 贴图数据起始位置
        color_start_offset = mmap_obj.tell()
        # 贴图数据结束位置
        color_end_offset = 0
        next_obj_start = None

        # 根据类型判断是否需要读取下一个物体头部
        if self.MESH_GVAL["type"] == "Map":
            log.debug("读取地图网格数据")
            # 查找下一个物体头部位置
            next_obj_start = self.find_next_head(
                mmap_obj, vertex_data["obj_vertex_block_size"]
            )
            # 贴图数据结束位置
            color_end_offset = mmap_obj.tell()
        elif self.MESH_GVAL["type"] == "Prop":
            log.debug("读取道具网格数据")
            # 贴图数据结束位置
            color_end_offset = mmap_obj.size()

        if next_obj_start is False:
            log.debug(f"未找到下一个物体头部地址, 处理最后一个网格")

        # 读取贴图数据
        colormap = self.read_colormap(mmap_obj, color_start_offset, color_end_offset)

        # 5. 构建并返回物体数据
        obj_data = {
            "mesh_obj_number": header["mesh_obj_count"],
            "obj_vertex_count": header["obj_vertex_count"],
            "vertex_data": vertex_data["vertex"],
            "faces_data": faces_data,
            "uvs": vertex_data["uvs"],
            "normals": vertex_data["normals"],
            "colormap": colormap,
        }
        
        # 为CW类型添加额外数据
        if self.MESH_GVAL["type"] == "CW":
            obj_data.update({
                "tangents": vertex_data["tangents"],
                "binormals": vertex_data["binormals"],
                "bone_indices": vertex_data["bone_indices"],
                "bone_weights": vertex_data["bone_weights"],
            })
        
        return obj_data

    def read_dynamic_head(self, mmap_obj: mmap.mmap):
        """读取头部信息"""
        log.debug(">>> 开始读取头部信息")

        try:
            # 包含的物体名称
            obj_names = []

            # 跳过前8字节
            mmap_obj.seek(0x8)

            # 包含数量 start
            mesh_include_obj_start = struct.unpack("<I", mmap_obj.read(0x4))[0]
            if mesh_include_obj_start == 0:
                log.debug("CW Mesh 包含物体数量为0,跳过读取")
                return {"CANCELLED"}

            # 读取包含的对象名称
            for _ in range(mesh_include_obj_start):
                # 读取物体名称长度
                name_length = struct.unpack("<I", mmap_obj.read(0x4))[0]
                # 读取物体名称
                obj_name = struct.unpack(
                    f"<{name_length}s", mmap_obj.read(name_length)
                )[0].decode("utf-8").strip('\x00')
                # log.debug("对象名称: %s", obj_name)
                # 保存名称
                obj_names.append(obj_name)

            # 包含数量 end
            mesh_include_obj_end = struct.unpack("<I", mmap_obj.read(0x4))[0]

            # 检查头部数量是否一致
            if mesh_include_obj_start != mesh_include_obj_end:
                log.error("! 头部信息解析失败: 包含的对象数量不一致")
                return {"CANCELLED"}

            # 读取物体的 MinPos MaxPos数据(0x18 == minPos(0xC) + maxPos(0xC))
            min_max_data_size = mesh_include_obj_start * 0x18
            min_max_data = mmap_obj.read(min_max_data_size)
            
            # 解析所有物体的MinPos MaxPos数据
            self.bbox_list = []
            for i in range(mesh_include_obj_start):
                offset = i * 0x18
                if offset + 0x18 <= min_max_data_size:
                    min_x, min_y, min_z, max_x, max_y, max_z = struct.unpack(
                        "<ffffff", min_max_data[offset:offset + 0x18]
                    )
                    bbox_data = {
                        'name': obj_names[i] if i < len(obj_names) else f"Object_{i}",
                        'min_position': (min_x, min_y, min_z),
                        'max_position': (max_x, max_y, max_z)
                    }
                    self.bounding_box_list.append(bbox_data)
                    # log.debug(f"CW {bbox_data['name']} - Min: {bbox_data['min_position']}, Max: {bbox_data['max_position']}")
            
            # 保存第一个物体的数据（向后兼容）
            if self.bounding_box_list:
                self.min_position = self.bounding_box_list[0]['min_position']
                self.max_position = self.bounding_box_list[0]['max_position']

            log.debug(f"read_min_max_pos: {hex(min_max_data_size)}, 共 {len(self.bounding_box_list)} 个边界框")

            # 返回 物体开始位置，物体信息
            return obj_names
        except Exception as e:
            log.error("! 读取头部信息失败: %s", e)
            return {"CANCELLED"}

    def check_cw_mesh_version(self, mmap_obj: mmap.mmap):
        """检查CW Mesh 版本"""
        log.debug(">>> 开始检查CW Mesh 版本")
        # 保存当前位置
        pos = mmap_obj.tell()

        # Mesh文件头部数据
        head_data = mmap_obj[pos : pos + 0x21]

        # 尝试读取关键字段
        try:
            # obj数量
            obj_count = struct.unpack_from("<I", head_data, 0x0)[0]
            # Mesh中第一个物体包含面数量
            obj_face_count = struct.unpack_from("<I", head_data, 0x4)[0]
            # Mesh中第一个物体包含顶点数量
            obj_vertex_count = struct.unpack_from("<I", head_data, 0x8)[0]
            # Mesh中第一个物体顶点数据大小 - V1版本
            obj_vbyte_v1 = struct.unpack_from("<I", head_data, 0x19)[0]
            # Mesh中第一个物体顶点数据大小 - V2版本
            obj_vbyte_v2 = struct.unpack_from("<I", head_data, 0x1D)[0]

            # 基本验证
            if obj_count <= 0 or obj_face_count <= 0 or obj_vertex_count <= 0:
                return

            # 面数据字节大小
            face_byte_size = obj_face_count * 0xC

            # 判断Mesh版本
            # 类型为 旧版本(V1) Mesh 文件(0x40 == 每组顶点数据字节大小)
            if obj_vbyte_v1 // obj_vertex_count == 0x40:
                # 从当前物体中获取面数据大小 (0x1D == V1版本的头部大小)
                get_face_byte = mmap_obj[
                    pos + 0x1D + obj_vbyte_v1 : pos + 0x1D + obj_vbyte_v1 + 0x4
                ]
                get_face_byte_size = struct.unpack("<I", get_face_byte)[0]
                log.debug(f"get_face_size : {get_face_byte}")

                # 验证计算出的面字节和实际读取到的面字节大小是否一致
                if get_face_byte_size == face_byte_size:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["CW_V1"]
                    log.debug("判定为 CW V1")
                else:
                    log.debug("------------ 不是 CW V1 或 V2 ------------")
            # 类型为 新版本(V2) Mesh 文件
            elif obj_vbyte_v2 // obj_vertex_count == 0x40:
                # 从当前物体中获取面数据大小 (0x21 == V2版本的头部大小)
                get_face_byte = mmap_obj[
                    pos + 0x21 + obj_vbyte_v2 : pos + 0x21 + obj_vbyte_v2 + 0x4
                ]
                get_face_byte_size = struct.unpack("<I", get_face_byte)[0]

                # 验证计算出的面字节和实际读取到的面字节大小是否一致
                if get_face_byte_size == face_byte_size:
                    self.MESH_GVAL = self.MESH_TYPE_CONFIGURATION["CW_V2"]
                    log.debug("判定为 CW V2")
                else:
                    log.debug("------------ 不是 CW V2 或 V1 ------------")

            # 首次更新总物体数
            if self.MESH_INCLUDE_OBJECT == 0:
                self.MESH_INCLUDE_OBJECT = obj_count
                self.mesh_object_count = obj_count  # 同步更新新属性

            return self.MESH_GVAL["version"]
        except Exception as e:
            log.debug(f"头部数据解析失败: {e}")
            return None

    def read_cw_head(self, mmap_obj: mmap.mmap):
        """读取人物或武器头部信息"""
        log.debug(">>> 开始读取头部信息")

        header_data = mmap_obj.read(self.MESH_GVAL["header_size"])

        # 本物体包含网格物体数量
        header = {
            "mesh_obj_count": struct.unpack_from("<I", header_data, 0x0)[0],
            "obj_face_count": struct.unpack_from("<I", header_data, 0x4)[0],
            "obj_vertex_count": struct.unpack_from("<I", header_data, 0x8)[0],
                "obj_vertex_byte": struct.unpack_from(
                    "<I", header_data, self.MESH_GVAL["vertex_bytes_offset"]
                )[0],
        }

        # todo: 验证数据是否有效

        # 返回文件中包含网格物体数量, 本物体面数据组数量, 本网格变换矩阵数量, 本网格字节总数
        return header

    def read_cw_vertex(
        self, mmap_obj: mmap.mmap, obj_vertex_count: int, obj_vertex_byte: int
    ):
        """读取人物或武器顶点数据"""
        log.debug(">>> 开始读CW取顶点数据")
        try:
            # 每个顶点数据块的大小
            block_size = obj_vertex_byte // obj_vertex_count

            # 读取顶点数据
            vertex_data = mmap_obj.read(obj_vertex_byte)

            # 顶点数据返回值
            res_data = {
                "vertex": [],
                "normals": [],
                "tangents": [],
                "binormals": [],
                "bone_indices": [],
                "bone_weights": [],
                "uv": [],
                "block_size": block_size,
            }

            for i in range(obj_vertex_count):
                # 计算当前块的起始位置
                v_offset = block_size * i
                # 确保有足够的字节进行解包
                if v_offset + block_size <= obj_vertex_byte:
                    # 顶点 - 单精度浮点
                    vx, vy, vz = struct.unpack_from("fff", vertex_data, v_offset)
                    # 将顶点添加到顶点列表
                    res_data["vertex"].append((vx, vy, vz))

                    # 法线​​ - 半精度浮点
                    nx, ny, nz = struct.unpack_from(
                        "<eee", vertex_data, v_offset + 0x0C
                    )
                    res_data["normals"].append((nx, ny, nz))

                    # 切线​ - 半精度浮点
                    tx, ty, tz = struct.unpack_from(
                        "<eee", vertex_data, v_offset + 0x14
                    )
                    res_data["tangents"].append((tx, ty, tz))

                    # 复法线​ - 半精度浮点
                    bx, by, bz = struct.unpack_from(
                        "<eee", vertex_data, v_offset + 0x1C
                    )
                    res_data["binormals"].append((bx, by, bz))

                    # 骨骼索引 - 字节x4 (0x24-0x27)
                    b0, b1, b2, b3 = struct.unpack_from("<BBBB", vertex_data, v_offset + 0x24)
                    res_data["bone_indices"].append((b0, b1, b2, b3))

                    # 骨骼权重 - 单精度浮点x4 (0x28-0x37)
                    w0, w1, w2, w3 = struct.unpack_from("<ffff", vertex_data, v_offset + 0x28)
                    res_data["bone_weights"].append((w0, w1, w2, w3))

                    # UV - 半精度浮点
                    uv_offset = v_offset + block_size - self.MESH_GVAL["uv_offset"]
                    u, v = struct.unpack_from("<ee", vertex_data, uv_offset)
                    res_data["uv"].append((u, 1 - v))

                else:
                    log.debug("! 顶点数据解析失败: 不足的字节数在偏移量 %s", v_offset)
                    break

            return res_data
        except Exception as e:
            log.debug("! 顶点CW数据解析失败: %s", e)
            # self.report({"ERROR"}, f"顶点CW数据解析失败 : {e}")
            # return {"CANCELLED"}
            return None

    def read_cw_faces(self, mmap_obj: mmap.mmap):
        """读取CW面数据"""
        log.debug(">>> 开始读取CW面数据")
        # 获取面数据字节大小
        face_byte_size = struct.unpack("<I", mmap_obj.read(0x4))[0]
        # 获取面数据
        faces_data = mmap_obj.read(face_byte_size)
        # 面数据返回值
        res_faces = []

        try:
            # 确保有足够的字节进行解包
            for i in range(0, face_byte_size, 12):
                f0, f1, f2 = struct.unpack_from("III", faces_data, i)
                res_faces.append((f0, f1, f2))

            return res_faces
        except Exception as e:
            log.error("! 面数据解析失败: %s", e)
            # traceback.print_exc()
            # return {"CANCELLED"}
            return None

    def process_character_weapon(self, mmap_obj: mmap.mmap):
        """处理人物和武器Mesh"""
        log.debug("处理人物和武器Mesh")

        # 对象数据
        mesh_obj = []

        try:
            # 读取动态头部,获取包含的物体名称
            obj_namess = self.read_dynamic_head(mmap_obj)
            # 保存物体名称到类成员变量
            if obj_namess and obj_namess != {"CANCELLED"}:
                self.obj_names = obj_namess

            # 判断CW Mesh 版本
            check_cw_version = self.check_cw_mesh_version(mmap_obj)
            if check_cw_version is None:
                log.debug("无法判断CW版本")
                return None

            # 依次处理每个物体
            while self.MESH_OBJECT_READED < self.MESH_INCLUDE_OBJECT:
                log.debug(">>> 读取网格信息名称")

                # 读取头部信息
                head_data = self.read_cw_head(mmap_obj)

                if head_data is None:
                    log.debug("! 读取头部信息失败")
                    break

                # 解析顶点数据块
                vertex_data = self.read_cw_vertex(
                    mmap_obj,
                    head_data["obj_vertex_count"],
                    head_data["obj_vertex_byte"],
                )

                # 判断是否读取失败
                if vertex_data is None:
                    log.debug("! 解析顶点数据失败")
                    # return mesh_obj
                    break

                # 获取面数据
                face_data = self.read_cw_faces(mmap_obj)

                # 判断是否读取失败
                if face_data is None:
                    log.debug("! 解析面数据失败")
                    # return mesh_obj
                    break

                # 贴图数据起始位置
                color_start_offset = mmap_obj.tell()
                # 贴图数据结束位置
                color_end_offset = 0
                next_obj_start = None

                # 根据Mesh包含数量判断是否需要读取下一个物体头部
                if self.MESH_INCLUDE_OBJECT > 1:
                    if self.MESH_OBJECT_READED < self.MESH_INCLUDE_OBJECT:
                        log.debug("读取下一个CW物体头部位置")
                        # 查找下一个物体头部位置
                        next_obj_start = self.find_next_head(
                            mmap_obj, vertex_data["block_size"]
                        )
                        color_end_offset = mmap_obj.tell()
                    else:
                        log.debug("不需要读取下一个CW物体头部位置")
                        color_end_offset = mmap_obj.size()
                elif self.MESH_INCLUDE_OBJECT == 1:
                    log.debug("不需要读取下一个CW物体头部位置")
                    color_end_offset = mmap_obj.size()

                if next_obj_start is False:
                    log.debug(f"未找到下一个物体头部地址, 处理最后一个网格")

                # 查找ColorMap
                colormap = self.read_colormap(
                    mmap_obj, color_start_offset, color_end_offset
                )

                # 向mesh_obj中添加数据
                mesh_data = {
                    "mesh_obj_number": head_data["mesh_obj_count"],
                    "obj_vertex_count": head_data["obj_vertex_count"],
                    "vertex_data": vertex_data["vertex"],
                    "faces_data": face_data,
                    "uvs": vertex_data["uv"],
                    "normals": vertex_data["normals"],
                    "colormap": colormap,
                }
                
                # 为CW类型添加额外数据
                if self.MESH_GVAL["type"] == "CW":
                    mesh_data.update({
                        "tangents": vertex_data["tangents"],
                        "binormals": vertex_data["binormals"],
                        "bone_indices": vertex_data["bone_indices"],
                        "bone_weights": vertex_data["bone_weights"],
                    })
                
                mesh_obj.append(mesh_data)

                self.MESH_OBJECT_READED += 1

            return mesh_obj, obj_namess
        except Exception as e:
            log.debug("! 分割网格数据失败: %s", e)
            # traceback.print_exc()
            return mesh_obj, None

    def parse_file(self, filepath: str) -> list:
        """解析网格文件"""

        # 重置解析状态
        self.reset_parser_state()

        # 返回值
        results = []

        try:
            # 打开文件并创建mmap对象
            with open(filepath, "rb") as f:
                with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mmap_obj:

                    # 首次读取头部数据时，尝试判断网格类型与版本
                    if self.MESH_GVAL["type"] == "Unset":
                        # 检查网格类型与版本
                        check_type = self.check_mesh_type_and_version(mmap_obj)
                        if check_type is None:
                            log.debug("无法判断网格类型")
                            return None

                    # 处理人物和武器Mesh
                    if self.MESH_GVAL["type"] == "CW":
                        log.debug("判定为 Character")
                        read_mesh_obj, obj_namess = self.process_character_weapon(
                            mmap_obj
                        )
                        if read_mesh_obj is None:
                            log.debug("读取人物或武器Mesh失败")
                        else:
                            results = read_mesh_obj

                    # 处理 静态Mesh - 地图和道具
                    else:
                        log.debug("判定为 Prop / Map")

                        # 1. 读取并验证MinPos MaxPos
                        if not self.read_minpos_maxpos(mmap_obj):
                            log.debug("读取MinPos MaxPos失败,或非有效网格文件!")
                            return None

                        # 2. 处理单个物体
                        while mmap_obj.tell() < mmap_obj.size():
                            # 读取并处理单个物体
                            obj_data = self.process_single_obj(mmap_obj)

                            # 检查是否读取到有效数据
                            if obj_data is None:
                                log.debug("读取物体数据失败，停止解析")
                                break

                            results.append(obj_data)
                            self.MESH_OBJECT_READED += 1

                            log.debug(
                                f"已处理 {self.MESH_OBJECT_READED} 个物体, 共 {self.MESH_INCLUDE_OBJECT} 个"
                            )

                            # 如果已经处理完所有物体，退出循环
                            if self.MESH_OBJECT_READED >= self.MESH_INCLUDE_OBJECT:
                                log.debug("已处理完所有物体，停止解析")
                                break

                log.info(
                    f"成功解析 {len(results)} 个网格对象，类型: {self.MESH_GVAL['type']}, 版本: {self.MESH_GVAL['version']}"
                )
                return results
        except Exception as e:
            log.error(f"文件解析失败: {e}")
            return []
